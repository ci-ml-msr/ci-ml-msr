library(datetime)
library(lubridate)
library(sqldf)
library(ggplot2)
library(rtern)
library(beanplot)
library(effsize)
library(tidyverse)
library(dplyr)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(data.table)
library(grid)
library(gridExtra)
library(changepoint)

###########################################################
# Defining work directory
###########################################################

current_file_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(current_file_dir)

# set the datasets folder as the working directory
setwd('../datasets')

###########################################################
# Import repository monthly intervals dataset
###########################################################

repos_month_date_intervals <- read.csv2("repos_month_date_intervals.csv", sep = ",", dec=".", na.strings = c('NULL'))

# Define the order of the boxes
loc_size_box_order <- c("small", "medium", "large")
box_order <- c("ML", "No ML")

# Reorder the factor levels
repos_month_date_intervals$loc_size <- reorder(repos_month_date_intervals$loc_size, as.numeric(factor(repos_month_date_intervals$loc_size, levels = loc_size_box_order)))
repos_month_date_intervals$generalProjectCategory <- reorder(repos_month_date_intervals$generalProjectCategory, as.numeric(factor(repos_month_date_intervals$generalProjectCategory, levels = box_order)))

###############################################################################
# PLOTING THE COLLECTED VARIABLES FOR THE STUDIED PROJECTS (E.G., medianRunDuration)
###############################################################################

repos_month_date_intervals$start_date <- as.Date(repos_month_date_intervals$start_date)

repos_data$abrupt_increases <- NA
repos_data$abrupt_decreases <- NA
repos_data$medianMonthlyPercentChangesRunDuration <- NA

projectCategories <- unique(repos_data$generalProjectCategory)
projectLocSizes <- sort(unique(repos_data$loc_size))

plots <- list()
projCount <- 0
for(generalProjectCategory in projectCategories){
  for(loc_size in projectLocSizes){
    
    fullNamesByCategoryAndSize <- unique(repos_month_date_intervals[repos_month_date_intervals$loc_size == loc_size & 
                                                                      repos_month_date_intervals$generalProjectCategory == generalProjectCategory,]$proj)
    
    print(paste(generalProjectCategory, loc_size, length(fullNamesByCategoryAndSize)))
    
    for(fullName in fullNamesByCategoryAndSize){
      
      projCount <- projCount + 1
      
      print(sprintf("#%s Proj: %s - %s %s", projCount, fullName, generalProjectCategory, loc_size))
      
      projData <- repos_month_date_intervals[repos_month_date_intervals$proj == fullName,]
      
      projData$lastCoverageInInterval <- projData$lastCoverageInInterval / 100
      
      # ----------------------------------------
      # PLOT 1
      # ----------------------------------------
      
      variables <- c("start_date",
                     "commitsCount",
                     "authors",
                     "runsInIntervalCount",
                     "submitedPRs"
      )
      
      labels <- c("commits", "authors", "runs", "submittedPRs")
      
      # Reshape the data from wide to long format
      data_long <- reshape2::melt(projData[,variables], id.vars = "start_date")
      
      plt <- ggplot(data_long, aes(x = start_date, y = value, color = variable, linetype = variable)) +
        # geom_line() +
        geom_line(na.rm = TRUE) +  # Add na.rm = TRUE to ignore NA values
        geom_point() +
        labs(x = "Date", y = "Value", title = paste(projData$generalProjectCategory, "-", projData$loc_size, "-", fullName)) +
        scale_linetype_manual(values = c("solid", "longdash", "dotdash", "solid", "twodash")) +
        theme(legend.position = "bottom", legend.title = element_blank())
      
      # ----------------------------------------
      # PLOT 2
      # ----------------------------------------
      
      variables <- c("start_date",
                     "submitedPRs",
                     "mergedPRs",
                     # "rejectedPRs",
                     "pullRequestContributors",
                     # "medianPRChurn",
                     # "medianPRChangedFiles",
                     # "medianPRCommits",
                     "medianPRMergeTimeInDays"
                     # "medianPRRejectTimeInDays"
      )
      
      # Reshape the data from wide to long format
      data_long <- reshape2::melt(projData[,variables], id.vars = "start_date")
      
      plt2 <- ggplot(data_long, aes(x = start_date, y = value, color = variable, linetype = variable)) +
        # geom_line() +
        geom_line(na.rm = TRUE) +  # Add na.rm = TRUE to ignore NA values
        geom_point() +
        labs(x = "Date", y = "Value", title = paste(projData$generalProjectCategory, "-", projData$loc_size, "-", fullName)) +
        scale_linetype_manual(values = c("solid", "longdash", "solid", "dotdash", "twodash",  "dotted", "dotdash", "longdash", "twodash", "solid")) +
        theme(legend.position = "bottom", legend.title = element_blank())
      
      # ----------------------------------------
      # PLOT 3
      # ----------------------------------------
      
      variables <- c("start_date",
                     # "commitsCount", 
                     # "authors", 
                     # "commitRatePerDay", 
                     # "commitRatePerDayExcludingWeekendDays",
                     # "commitsPerAuthor",
                     "commitActivity",
                     "runsActivity",
                     # "runsInIntervalCount",
                     # "medianRunDurationInMinutes",
                     # "fixedRunsInInterval",
                     # "medianTimeToFixRunsInHours",
                     "runsHealth",
                     "lastCoverageInInterval"
      )
      
      # Reshape the data from wide to long format
      
      data_long <- reshape2::melt(projData[,variables], id.vars = "start_date")
      
      # Interpolate missing values using na.approx()
      # By using na.approx() to interpolate missing values, the line will smoothly 
      # connect data points even when there are gaps in the time series, creating 
      # a visually continuous plot. The geom point will not be presented for those 
      # missing values, but the line will still follow straight to the next available data point.
      # data_long$value <- zoo::na.approx(data_long$value)
      
      plt3 <- ggplot(data_long, aes(x = start_date, y = value, color = variable, linetype = variable)) +
        # geom_line() +
        geom_path() +
        # geom_line(na.rm = TRUE) +  # Add na.rm = TRUE to ignore NA values
        geom_point() +
        labs(x = "Date", y = "Value", title = paste(projData$generalProjectCategory, "-", projData$loc_size, "-", fullName)) +
        scale_linetype_manual(values = c("solid", "longdash", "solid", "dotdash", "", "twodash")) +
        theme(legend.position = "bottom", legend.title = element_blank())
      
      # ----------------------------------------
      # PLOT 4
      # ----------------------------------------
      
      # projData$medianTimeToFixRunsInDays <- projData$medianTimeToFixRunsInHours / 24
      
      variables <- c("start_date",
                     # "commitRatePerDay",
                     "medianRunDurationInMinutes"
      )
      
      # Reshape the data from wide to long format
      data_long <- reshape2::melt(projData[!is.na(projData$medianRunDurationInMinutes),variables], id.vars = "start_date")
      
      # Detect change points
      ts_data <- projData[!is.na(projData$medianRunDurationInMinutes),variables]
      
      cpt_result <- NA
      change_points <- NA
      tryChangePointIdentification <- TRUE
      q_value <- NA
      while(tryChangePointIdentification){
        # Use tryCatch to capture and read the error message
        tryCatch({
          if(is.na(q_value)){
            cpt_result <<- cpt.mean(ts_data$medianRunDurationInMinutes, method = 'BinSeg')  
          }else{
            print(paste('changepoint::cpt.mean with Q =', q_value))
            cpt_result <<- cpt.mean(ts_data$medianRunDurationInMinutes, method = 'BinSeg', Q = q_value)
            print("changepoint::cpt.mean was executed successfuly!")
          }
          change_points <<- cpts(cpt_result)
          tryChangePointIdentification <<- FALSE
          q_value <<- NA
        }, error = function(e) {
          error_message <- conditionMessage(e)
          
          print(paste("ERROR:", error_message))
          
          # Define the regex pattern to match the number of segments
          pattern <- "Q is larger than the maximum number of segments (\\d+)"
          
          # If there are no meaningful changes in your data, you may not get any change points detected
          pattern2 <- "Minimum segment legnth is too large to include a change in this data"
          
          # Use regex to extract the number of segments
          matches <- str_match(error_message, pattern)
          
          # Check if a match is found
          if (!is.na(matches[2])) {
            num_segments <- as.numeric(matches[2])
            q_value <<- num_segments - 1
          } else {
            if (error_message == pattern2){
              cat("There are no meaningful changes in the data.\n")  
            }else{
              cat("No match found for the number of segments.\n")
            }
            q_value <<- NA
            change_points <<- NA
            cpt_result <<- NA
            tryChangePointIdentification <<- FALSE
          }
        })
        # if(!tryChangePointIdentification){
        #   break
        # }
      }
      
      # change_points <- cpts(cpt_result)
      
      column_names <- c("yintercept", "xmin", "xmax")
      hlines_df <- data.frame(matrix(nrow = 0, ncol = length(column_names)))
      colnames(hlines_df) <- column_names
      
      
      # Split the time series into segments based on the change points
      if(!is.na(change_points) && length(change_points) > 0){
        for (i in 1:(length(change_points) + 1)) {
          if (i == 1) {
            segmentIndices <- 1:change_points[i]
          } else if (i == length(change_points) + 1) {
            segmentIndices <- (change_points[i - 1] + 1):nrow(ts_data)
          } else {
            segmentIndices <- (change_points[i - 1] + 1):change_points[i]
          }
          segment <- ts_data[segmentIndices,]$medianRunDurationInMinutes
          
          projSegmentData <- ts_data[segmentIndices,]
          segmentMedianRunDurationInMinutes <- projSegmentData$medianRunDurationInMinutes
          yintercept <- mean(segmentMedianRunDurationInMinutes)
          # print(segmentIndices)
          # print(segment)
          hlines_df_row <- data.frame(yintercept = yintercept,
                                      xmin = min(projSegmentData$start_date),
                                      xmax = max(projSegmentData$start_date))
          hlines_df <- rbind(hlines_df, hlines_df_row)
        }  
      }  
      
      # Loop through the breakpoint segments to assess the direction of each segment
      abrupt_increases <- 0
      abrupt_decreases <- 0
      if(nrow(hlines_df) >= 2){
        for(i in 1:(nrow(hlines_df) - 1)){
          if(hlines_df[i,]$yintercept > hlines_df[i + 1,]$yintercept){
            abrupt_decreases <- abrupt_decreases + 1
          }else{
            abrupt_increases <- abrupt_increases + 1
          }
        }  
      }
      
      # calculating the mean percentage of monthly changes in medianRunDurationInMinutes
      medianMonthlyPercentChangesRunDuration <-  median(projData$Percentage_Difference, na.rm = TRUE)
      
      percentChangesRunDurationDirection <- if_else(medianMonthlyPercentChangesRunDuration > 0, "increase", "decrease")
      
      
      medianRunDurationInMinFirstMonth <- ts_data[1,]$medianRunDurationInMinutes
      medianRunDurationInMinLastMonth <- ts_data[nrow(ts_data),]$medianRunDurationInMinutes
      diffInFirstAndLastMonth <- round(medianRunDurationInMinLastMonth - medianRunDurationInMinFirstMonth, 2)
      diffInPercentage <- round(diffInFirstAndLastMonth / medianRunDurationInMinFirstMonth  * 100, 2)
      
      df <- data.frame(Date = ts_data$start_date, Value = ts_data$medianRunDurationInMinutes, ChangePoint = FALSE)
      df$ChangePoint[change_points] <- TRUE
      
      # adding processed values of runDuration to the repos_data data.frame      
      repos_data[repos_data$fullName == fullName,]$abrupt_increases <- abrupt_increases
      repos_data[repos_data$fullName == fullName,]$abrupt_decreases <- abrupt_decreases
      repos_data[repos_data$fullName == fullName,]$medianMonthlyPercentChangesRunDuration <- round(medianMonthlyPercentChangesRunDuration, 1)
      
      plt4 <- ggplot(df, aes(x = Date, y = Value, color = 'medianRunDurationInMinutes')) +
        geom_line() +
        geom_point() +
        # geom_point(data = df[change_points, ], color = "black", size = 2) +
        geom_vline(xintercept = df$Date[df$ChangePoint == TRUE], linetype = "dashed", color = "black") +
        geom_segment(data = hlines_df, aes(x = xmin, xend = xmax, y = yintercept, yend = yintercept), linetype = "solid", color = "black") +
        labs(x = "Date", y = "Value", 
             title = paste(projData$generalProjectCategory, "-", projData$loc_size, "-", fullName),
             subtitle = sprintf("Abrupt increases: %s - Abrupt decreases: %s\nMedian %s in RunDuration per month: %s%%", abrupt_increases, abrupt_decreases, percentChangesRunDurationDirection, round(medianMonthlyPercentChangesRunDuration, 1))) +
        theme(legend.position = "bottom", legend.title = element_blank())
      
      plots[[length(plots) + 1]] <- plt
      plots[[length(plots) + 1]] <- plt2
      plots[[length(plots) + 1]] <- plt3
      plots[[length(plots) + 1]] <- plt4
    }
  }
}

layout_mat <- matrix(1:4, nrow = 2, ncol = 2, byrow = TRUE)

plots_temp <- marrangeGrob(plots, layout_matrix=layout_mat)

ggsave(filename="../plots/monthly-metrics-plot.pdf", plots_temp, width=297, height=210, units="mm")
