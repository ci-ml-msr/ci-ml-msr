##############################################
########### IMPORTING PACKAGES  ##############
##############################################

library(tidyverse)
library(dplyr)
library(openxlsx)
library(stringr)

###########################################################
# Defining working directory
###########################################################

current_file_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(current_file_dir)

# set the datasets folder as the working directory
setwd('../datasets')

###########################################################
# Importing  dataset
###########################################################

# Reading Excel sheets
prs_with_codes_ml <- read.xlsx("qualitative-study-datasets/stratified_prs_sample_v4_thematic_analysis_codes.xlsx", sheet = "ml_merge")
prs_with_codes_no_ml <- read.xlsx("qualitative-study-datasets/stratified_prs_sample_v4_thematic_analysis_codes.xlsx", sheet = "no_ml_merge")

###########################################################
# Spliting and count the codes
###########################################################

# Split the codes into distinct lines
separated_ml_codes <- prs_with_codes_ml %>%
  separate_rows(merge_polished, sep = ";\\s*") %>%
  filter(merge_polished != "") %>%
  mutate(merge_polished = str_trim(merge_polished)) %>%
  select(merge_polished)

# Count codes ocurrences
ml_codes_count <- separated_ml_codes %>%
  count(merge_polished, sort = TRUE)

# removing "not a CI discussion" and "documentation generation" codes
ml_codes_count <- ml_codes_count[!(ml_codes_count$merge_polished %in% c("not a CI discussion", "documentation generation")),]

# Calculate the percentage
ml_prs_with_CI_discussion <- nrow(prs_with_codes_ml[!(prs_with_codes_ml$merge_polished %in% c("not a CI discussion", "documentation generation")),])

ml_codes_count$percentage <- (ml_codes_count$n / ml_prs_with_CI_discussion) * 100

# Print the result
print(ml_codes_count)

# ----------

# Split the codes into distinct lines
separated_no_ml_codes <- prs_with_codes_no_ml %>%
  separate_rows(merge_polished, sep = ";\\s*") %>%
  filter(merge_polished != "") %>%
  mutate(merge_polished = str_trim(merge_polished)) %>%
  select(merge_polished)

# Count codes ocurrences
no_ml_codes_count <- separated_no_ml_codes %>%
  count(merge_polished, sort = TRUE)

# removing "not a CI discussion" and "documentation generation" codes
no_ml_codes_count <- no_ml_codes_count[!(no_ml_codes_count$merge_polished %in% c("not a CI discussion", "documentation generation")),]

# Calculate the percentage
no_ml_prs_with_CI_discussion <- nrow(prs_with_codes_no_ml[!(prs_with_codes_no_ml$merge_polished %in% c("not a CI discussion", "documentation generation")),])

no_ml_codes_count$percentage <- (no_ml_codes_count$n / no_ml_prs_with_CI_discussion) * 100

# Print the result
print(no_ml_codes_count)

# -----------

# Show the list of distinct codes and their counting
print(ml_codes_count)
print(no_ml_codes_count)

###########################################################
# Export Excell sheet with individual codes count
###########################################################

wb <- createWorkbook()

# Add the data frames to different sheets in the workbook
addWorksheet(wb, "ml_codes_count")
writeData(wb, sheet = 1, x = ml_codes_count, startCol = 1, startRow = 1)

addWorksheet(wb, "no_ml_codes_count")
writeData(wb, sheet = 2, x = no_ml_codes_count, startCol = 1, startRow = 1)

# Save the workbook to an Excel file
saveWorkbook(wb, "qualitative-study-datasets/qualitative_analysis_codes_count.xlsx", overwrite = TRUE)


###########################################################
# Counting non-bot comments in PRs with CI discussion
###########################################################

get_authorlogin_from_comment <- function(comment){
  # Regular expression pattern to extract author login
  # pattern <- "authorLogin:\\s+(\\w+)"
  pattern <- "authorLogin:\\s+([^\n]+)"
  
  # Extract author login using str_match()
  match_result <- str_match(comment, pattern)
  
  # Extracted author login
  author_login <- match_result[1, 2]
  return(author_login)
}

count_non_bot_comments_from_pull_request_comments <- function(commentsText){
  
  non_bot_comments <- 0
  
  comment_spliter <- "-----------------------------------------\n"
  
  split_result <- strsplit(commentsText, comment_spliter)
  
  # Extract the first element of the resulting list (which is a character vector)
  comment_list <- split_result[[1]]
  
  bot_login_pattern <- "\\b(bot|ci|codecov|coveralls|github-actions|dependabot|bors|seldondev|appleboy|netlify|vercel|azure|pipeline(s)?)\\b"
  
  filtered_comments <- c()
  
  for(commentText in comment_list){
    
    # get the authorLogin from the commentbot_login_pattern regex
    authorlogin <- get_authorlogin_from_comment(commentText)
    
    isKnownBotLogin <- grepl(bot_login_pattern, authorlogin, ignore.case = FALSE)  
    
    # filter out comments with authorLogin matchin the 
    if (!isKnownBotLogin) {
      non_bot_comments <- non_bot_comments + 1
    }
  }
  
  return(non_bot_comments)
}

# ---------------------------------------------------------
# Counting non-bot comments in PRs with CI discussion in ML projects 
# ---------------------------------------------------------
ml_prs_with_valid_ci_related_codes <- prs_with_codes_ml[prs_with_codes_ml$merge_polished != 'not a CI discussion',]
ml_prs_with_valid_ci_related_codes$non_bot_comments_count <- NA
ml_prs_with_valid_ci_related_codes$codes_count <- NA

for(row_index in 1:nrow(ml_prs_with_valid_ci_related_codes)){
  # non-bot comments count
  pull <- ml_prs_with_valid_ci_related_codes[row_index, ]
  non_bot_comments_count <- count_non_bot_comments_from_pull_request_comments(pull$comments)
  
  # codes count
  codes_split <- strsplit(pull$merge_polished, ";\\s*")
  codes_count <- length(codes_split[[1]])
  
  comment_spliter <- "-----------------------------------------\n"
  comments_split <- strsplit(pull$comments, comment_spliter)
  comments_count <- length(codes_split[[1]])
  
  ml_prs_with_valid_ci_related_codes[row_index, ]$non_bot_comments_count <- non_bot_comments_count
  ml_prs_with_valid_ci_related_codes[row_index, ]$codes_count <- codes_count
}

# ---------------------------------------------------------
# Counting non-bot comments and the number of codes from thematic analysis in PRs with CI discussion in non-ML projects 
# ---------------------------------------------------------

no_ml_prs_with_valid_ci_related_codes <- prs_with_codes_no_ml[prs_with_codes_no_ml$merge_polished != 'not a CI discussion',]
no_ml_prs_with_valid_ci_related_codes$non_bot_comments_count <- NA
no_ml_prs_with_valid_ci_related_codes$codes_count <- NA

for(row_index in 1:nrow(no_ml_prs_with_valid_ci_related_codes)){
  pull <- no_ml_prs_with_valid_ci_related_codes[row_index, ]
  non_bot_comments_count <- count_non_bot_comments_from_pull_request_comments(pull$comments)
  codes_split <- strsplit(pull$merge_polished, ";\\s*")
  codes_count <- length(codes_split[[1]])
  
  no_ml_prs_with_valid_ci_related_codes[row_index, ]$non_bot_comments_count <- non_bot_comments_count
  no_ml_prs_with_valid_ci_related_codes[row_index, ]$codes_count <- codes_count
}

# ---------------------------------------------------------
# Getting descriptive statistic about comments count in PR with CI discussion
# ---------------------------------------------------------

# summarizing non_bot_comments_count in PRs from ML projects 
summary(ml_prs_with_valid_ci_related_codes$non_bot_comments_count)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 2.000   3.250   6.000   9.662  12.000  70.000 

# summarizing non_bot_comments_count in PRs from non-ML projects
summary(no_ml_prs_with_valid_ci_related_codes$non_bot_comments_count)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 2.000   4.000   7.000   8.863  11.000  55.000


# ---------------------------------------------------------
# Getting descriptive statistic about codes count in PR with CI discussion
# ---------------------------------------------------------

# summarizing codes_count in PRs from ML projects 
summary(ml_prs_with_valid_ci_related_codes$codes_count)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 1.000   1.000   2.000   2.245   3.000  11.000 

# summarizing codes_count in PRs from non-ML projects
summary(no_ml_prs_with_valid_ci_related_codes$codes_count)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 1.000   1.000   2.000   2.275   3.000   6.000 


###########################################################
# Getting the codes that emerges uniquely in ML or non-ML projects discussions
###########################################################

specific_ml_codes_count <- ml_codes_count[which(!(ml_codes_count$merge_polished %in% no_ml_codes_count$merge_polished)),]
View(specific_ml_codes_count)

specific_no_ml_codes_count <- no_ml_codes_count[which(!(no_ml_codes_count$merge_polished %in% ml_codes_count$merge_polished)),]
View(specific_no_ml_codes_count)