README

1. To create the netowrk-graph with Neovi.js, we need to create a Neo4J database;
2. We use Neo4J Desktop to create a Neo4J database ;
3. After the database creation, we use the data from "ml_qualitative_analysis_codes_count_axial.csv" and
"no_ml_qualitative_analysis_codes_count_axial.csv" to populate the database;
4. First, we populate the database with data from "ml_qualitative_analysis_codes_count_axial.csv", them we open the "index.html" on the browser to get the netowrk-graph with Neovi.js -> OBS: we use a python server to serve the "index.html" page (python3 -m http.server);
5. We delete all nodes of the Neo4J database before populate the database with "no_ml_qualitative_analysis_codes_count_axial.csv";
5. We populate the database with data from "no_ml_qualitative_analysis_codes_count_axial.csv", them we open the "index.html" on the browser to get the netowrk-graph with Neovi.js;


// SCRIPTS TO LOAD THE CSV DATA INTO NEO4J DATABASE
LOAD CSV WITH HEADERS FROM 'file:///ml_qualitative_analysis_codes_count_axial.csv' AS row
WITH row WHERE row.category IS NOT NULL
MERGE (category:Category {name: row.category})
MERGE (theme:Theme {name: row.theme, category: row.category, theme: row.theme})
MERGE (code:Code {name: row.code, count: toInteger(row.count),
                 theme: row.theme,
                 category: row.category})
MERGE (theme)-[:HAS_CODE]->(category)
MERGE (code)-[:HAS_CODE {count: row.count}]->(theme);


// SCRIPT TO DELETE ALL NODES OF THE NEO4J DATABASE
MATCH (n) DETACH DELETE n


// RETRIEVING ALL NODES OF THE NEO4J DATABASE
MATCH (n)-[r:HAS_CODE]->(m) RETURN n,r,m