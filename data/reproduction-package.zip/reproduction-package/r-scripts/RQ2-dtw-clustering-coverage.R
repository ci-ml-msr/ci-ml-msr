##############################################
########### IMPORTING PACKAGES  ##############
##############################################

# library(tseries)
# library(ggdendro) # dendrograms
# library(gplots) # heatmap
# library(cluster)
# library(factoextra)

library(dtw)
# library(proxy)
library(dtwclust)
library(tidyverse)
# library(NbClust)
# library(clValid)
# library(BBmisc)
# library(kableExtra)

library(tidyr)
library(gridExtra)
library(sqldf)

# Fill NA values using linear interpolation
library(zoo)

###########################################################
# Defining work directory
###########################################################

current_file_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(current_file_dir)

# set the datasets folder as the working directory
setwd('../datasets')

##################################################
############### LOADING DATASETS #################
##################################################

seed <- 12345

set.seed(seed)

repos_month_date_intervals <- read.csv2("repos_month_date_intervals.csv", sep = ",", dec=".", na.strings = c('NULL'))

# Define the order of the boxes
loc_size_box_order <- c("small", "medium", "large")
box_order <- c("ML", "No ML")

# Reorder the factor levels
repos_month_date_intervals$loc_size <- reorder(repos_month_date_intervals$loc_size, as.numeric(factor(repos_month_date_intervals$loc_size, levels = loc_size_box_order)))
repos_month_date_intervals$generalProjectCategory <- reorder(repos_month_date_intervals$generalProjectCategory, as.numeric(factor(repos_month_date_intervals$generalProjectCategory, levels = box_order)))

##################################################
# FILTERING PROJECTS WITH SUITABLE COVERAGE DATA #
##################################################

projects_coverage_count <- summarise(
  group_by(repos_month_date_intervals[!is.na(repos_month_date_intervals$lastCoverageInInterval),], proj), 
  coverage_history_count = length(proj))


projects_min_6_monthly_coverage_data <- projects_coverage_count[projects_coverage_count$coverage_history_count >= 6,]$proj


##################################################
### CREATION OF COVERAGE TIME SERIES DATAFRAME ###
##################################################

time_series_df <- repos_month_date_intervals %>% filter(proj %in% projects_min_6_monthly_coverage_data &
                                                          !is.na(lastCoverageInInterval) & 
                                                          generalProjectCategory == 'ML'
                                                          # generalProjectCategory == 'No ML'
) %>% select(proj,
             loc_size,
             intervalOrder,
             lastCoverageInInterval)


# creates a list of lastCoverageInInterval values for each project
time_series.list <- lapply(split(time_series_df$lastCoverageInInterval, time_series_df$proj), as.numeric)

##################################################
# Data Preprocessing (Interpolating and Scaling) #
##################################################

# Linear Interpolation to set the same amount of elements to the time series of all projects
max_length <- max(lengths(time_series.list))
time_series.interpolated <- reinterpolate(time_series.list, new.length = max_length)
time_series.matrix.interpolated <- t(sapply(time_series.interpolated, unlist))

# This is a pre-modelling step. In this step, the data must be scaled or standardised 
# so that different attributes can be comparable. Standardised data has mean zero and 
# standard deviation one. we do this using scale() function

time_series.matrix.scaled <- zscore(time_series.matrix.interpolated)

# time_series.matrix.scaled <- t(scale(t(time_series.matrix.interpolated)))

##################################################
#      GETTING THE OPTMAL NUMBER OF CLUSTERS     #
#               GAP statistic                    #
##################################################

kmax <-  nrow(time_series.matrix.scaled) - 1

set.seed(12345); system.time(
  gap_stat <- clusGap(time_series.matrix.scaled, FUN = kmeans,
                      nstart = 25, iter.max = 50,
                      K.max = kmax, B = 500)
)

# getting the optmal number of clusters based on gap statistic
best_k_clusters <- maxSE(f = gap_stat$Tab[, "gap"], SE.f = gap_stat$Tab[, "SE.sim"])
ggp <- fviz_gap_stat(gap_stat)
plot(ggp)

# ML with seed 12345 gives clusgap = 2 (scaled)
# NoML with seed 12345 gives clusgap = 5 (scaled)

##################################################
#     CREATING CLUSTERS BASED IN DTW DISTANCE    #
##################################################

best_k_clusters <- 2

# The number of clusters used in the clustering algorithm is based on gap statistic

# This code uses fuzzy algorithm to clustering the time series
# Through manual analysis of the clustering algotithm, the fuzzy was the one
# that best clustered the time series data for test coverage
clusters <- tsclust(time_series.matrix.interpolated, type="fuzzy", seed=12345, k=best_k_clusters, distance="dtw2")

# Ploting the genereted clusters (series + centroids)
# Note: It's possible to plot series or centroids separately by using type = "s" or type = "c"
plot(clusters, type = "sc")

##################################################
#        CUSTOMIZING THE CLESTERING PLOTS        #
##################################################

# This code customizes the clusters' plots by including the centroid in the black color.
# Also, we fit and plot a regression model based on the centroid of each cluster to help us 
# manually classify the clustes's trends in "increasing", "decreasing" or "maintaining".

# Getting and Converting the centroid matrix to a long format
time_series.centroids.matrix <- sapply(clusters@centroids, unlist)
# data_long_centroids <- gather(time_series.centroids.df, key = "Column", value = "Value")

# This list stores the customized plots of each cluster generated by the clustering algorithm
clusters_plots <- list()


# This list stores the classification of the centroid trends for each cluster
clusters.trends.classification <- c()


clusters.time_series.matrix <- t(sapply(clusters@datalist, unlist))

# Iterate through each cluster
index <- 1
for (cluster_id in sort(unique(clusters@cluster))) {
  
  # Extract cluster members
  members_index <- which(cluster_id == clusters@cluster)
  
  # Filtering the time series grouped in the current cluster (cluster_id)
  if(length(members_index) == 1){
    # When the cluster has only one time series we have to ensure that the time series
    # values will be put into a data.frame instead of a vector
    colname <- rownames(clusters.time_series.matrix)[members_index]
    cluster_df <- data.frame(clusters.time_series.matrix[members_index,])
    colnames(cluster_df) <- colname
  }else{
    cluster_df <- data.frame(t(clusters.time_series.matrix[members_index,]))  
  }
  
  cluster_df.list <- as.list(cluster_df)
  
  long_df <- enframe(cluster_df.list, name = "Variable", value = "Values") %>%
    unnest(Values)
  
  # Create a new column with the sequence that restarts when "Variable" changes
  long_df <- long_df %>%
    group_by(Variable) %>%
    mutate(Sequence = row_number())
  
  # Calculate DBA centroid
  centroid <- time_series.centroids.matrix[,c(cluster_id)]
  
  # Create a data frame for the centroid
  centroid_df <- data.frame(
    Sequence = 1:length(centroid),
    Centroid = centroid
  )
  
  # Fit a linear model to the centroid values
  lm_result <- lm(centroid_df$Centroid ~ centroid_df$Sequence)
  
  # Extract intercept and slope coefficients
  intercept <- coef(lm_result)[1]
  slope <- coef(lm_result)[2]
  
  cluster_trend <- NA
  if(round(slope, 2) > 0.030){
    cluster_trend <- "Increasing"
  }else if(round(slope, 2) < -0.030){
    cluster_trend <- "Decreasing"
  }else{
    cluster_trend <- "Maintaining"
  }
  
  clusters.trends.classification <- c(clusters.trends.classification, cluster_trend)
  
  print(paste("Cluster", cluster_id, "-", cluster_trend, "- Slope:",slope))
  
  cluster_trend <- "Maintaining"
  
  # -----------------------------------------------------
  # Generating the cluster plot object (p) 
  # to be stored in the clusters_plots list
  # -----------------------------------------------------
  plot_title <- paste("Cluster", cluster_id)
  
  # Convert the cluster time series matrix to a data frame
  cluster_df <- as.data.frame(t(clusters.time_series.matrix[members_index,]))
  # cluster_df$time_step <- 1:nrow(cluster_df)
  
  # Plot the data as time series with the added Sequence column
  p <- ggplot() +
    geom_line(data = long_df, aes(x = Sequence, y = Values, group = Variable, color = Variable)) +
    geom_line(data = centroid_df, aes(x = Sequence, y = Centroid), 
              color = "black", linetype = "dashed", linewidth = 1.5) +
    labs(x = "", y = "") +
    theme_minimal() +
    theme(legend.position = "none",
          axis.title.x = element_blank(), 
          axis.text.x = element_blank(),
          plot.title = element_text(hjust = 0.5,
                                    face="bold"),
          plot.subtitle=element_text(hjust=0.5)) +
    labs(title=plot_title,
         subtitle=cluster_trend) +
    geom_abline(intercept = intercept, slope = slope, color = "red", linewidth = 1.0) +
    scale_y_continuous(limits = c(0, 100))
  # labs(title=plot_title) +
  # scale_y_continuous(limits = c(-2, 5)) +
  # labs(title=plot_title,
  #      subtitle=cluster_trend)
  
  
  clusters_plots[[index]] <- p
  index <- index + 1
}

# ---------------------------------------------------------------
# Ploting the customized clusters' plots from clusters_plots list
# ---------------------------------------------------------------

# library(cowplot)

# Arrange plots using gridExtra
arranged_plots <- grid.arrange(
  grobs = clusters_plots,
  ncol = 2
)
