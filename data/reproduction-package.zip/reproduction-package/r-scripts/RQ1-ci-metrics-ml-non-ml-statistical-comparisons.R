library(datetime)
library(lubridate)
library(sqldf)
library(ggplot2)
library(rtern)
library(beanplot)
library(effsize)
library(tidyverse)
library(dplyr)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(data.table)
library(grid)
library(gridExtra)
library(changepoint)

###########################################################
# Define work directory
###########################################################

current_file_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(current_file_dir)

# set the datasets folder as the working directory
setwd('../datasets')

###########################################################
# Import repository dataset
###########################################################

repos_data <- read.csv2("repositories-info_with_ci_metrics.csv", sep = ",", dec=".", na.strings = c('NULL'))

# Define the order of the boxes
box_order <- c("ML", "No ML")

# Define the order of the boxes
loc_size_box_order <- c("small", "medium", "large")

# Reorder the factor levels
repos_data$generalProjectCategory <- reorder(repos_data$generalProjectCategory, 
                                             as.numeric(factor(repos_data$generalProjectCategory, 
                                                               levels = box_order)))

# Reorder the factor levels
repos_data$loc_size <- reorder(repos_data$loc_size, 
                               as.numeric(factor(repos_data$loc_size, 
                                                 levels = loc_size_box_order)))

###########################################################
# Import repository monthly intervals dataset
###########################################################

repos_month_date_intervals <- read.csv2("repos_month_date_intervals.csv", sep = ",", dec=".", na.strings = c('NULL'))

# Define the order of the boxes
loc_size_box_order <- c("small", "medium", "large")
box_order <- c("ML", "No ML")

# Reorder the factor levels
repos_month_date_intervals$loc_size <- reorder(repos_month_date_intervals$loc_size, as.numeric(factor(repos_month_date_intervals$loc_size, levels = loc_size_box_order)))
repos_month_date_intervals$generalProjectCategory <- reorder(repos_month_date_intervals$generalProjectCategory, as.numeric(factor(repos_month_date_intervals$generalProjectCategory, levels = box_order)))

###############################################################################
#
# STATISTICAL ANALYSIS and PLOTTING VARIABLES' DISTRIBUTION
#
###############################################################################

###############################################################################
# STATISTICAL ANALYSIS: Verifying assumptions for executing the MWW test
###############################################################################
# --------------------------------------------------------------------------
# verifying the normality of the data prior to MWW test
# --------------------------------------------------------------------------

columns <- c("commitActivity", "lastCoverageInInterval", "medianRunDurationInMinutes", 
             "runsHealth", "medianTimeToFixRunsInHours")

shapiro_results <- repos_month_date_intervals %>%
  group_by(loc_size, generalProjectCategory) %>%
  summarise(across(all_of(columns), ~ shapiro.test(.)$p.value, .names = "{.col}_pvalue")) %>%
  ungroup()

# Observing the shapiro test p-values for the distributions of our dataset
# -- All the distributions deviate from a normal distribution
cbind(shapiro_results[, seq(1, 2)], shapiro_results[, seq(3, length(shapiro_results))] <= 0.05)


############################################################################
# Applying the MWW test - Time to Fix
############################################################################

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(medianTimeToFixRunsInHours ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianTimeToFixRunsInHours ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianTimeToFixRunsInHours ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

metric_summary <-
  summarise(group_by(repos_data, loc_size, generalProjectCategory), 
            projects = length(medianTimeToFixRunsInHours),
            min = min(medianTimeToFixRunsInHours, na.rm = TRUE),
            q1 = quantile(medianTimeToFixRunsInHours, probs = 0.25, na.rm = TRUE),
            median = median(medianTimeToFixRunsInHours, na.rm = TRUE),
            mean = mean(medianTimeToFixRunsInHours, na.rm = TRUE),
            q3 = quantile(medianTimeToFixRunsInHours, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(medianTimeToFixRunsInHours)$stats[5],
            max = max(medianTimeToFixRunsInHours, na.rm = TRUE))

# ----------------------------------------
# Visualization: bean plots 
# ----------------------------------------

par(xpd=F, mai = c(0.5, 0.8, 0.1, 0.1))

beanplot(medianTimeToFixRunsInHours ~ generalProjectCategory*loc_size, 
         data = repos_data %>% filter(!is.na(medianTimeToFixRunsInHours)), 
         ll = 0.08,
         # main = "beanplot", 
         what = c(0, 1, 1, 1),
         ylab = "Median Time to Fix Builds (Hours)", 
         side = "both",
         col = list("#F8766D", "#00BFC4"),
         # log = "",
         beanlines = "median"
)

legend("bottomleft", fill = c("#F8766D", "#00BFC4"), legend = c("ML", "No ML"))

# ----------------------------------------
# Visualization: box plots with p-values
# ----------------------------------------

bxp <- ggboxplot(repos_data %>% filter(!is.na(medianTimeToFixRunsInHours)), x = "loc_size", y = "medianTimeToFixRunsInHours", 
                 # outlier.shape = NA,
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Median Time To Fix Builds (Hours)") +
  scale_y_continuous(
    limits = c(0, 625)
  ) +
  stat_pvalue_manual(stat.test, hide.ns = FALSE, label = 'p = {p}\nCliffs\' Delta = {cliffs_magnitude}',
                     bracket.nudge.y = 0.03) +
  geom_text(data = metric_summary, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) 

ggpar(bxp,legend = "right", legend.title = "Category")

############################################################################
# Applying the MWW test - Test Coverage
############################################################################

##################################################
# FILTERING PROJECTS WITH SUITABLE COVERAGE DATA #
##################################################

projects_coverage_count <- summarise(
  group_by(repos_month_date_intervals[!is.na(repos_month_date_intervals$lastCoverageInInterval),], proj), 
  coverage_history_count = length(proj))


projects_min_6_monthly_coverage_data <- projects_coverage_count[projects_coverage_count$coverage_history_count >= 6,]$proj

repos_data_with_coverage_info <- repos_data[repos_data$fullName %in% projects_min_6_monthly_coverage_data,]

# stat.test <- repos_data %>%
#   group_by(loc_size) %>%
#   wilcox_test(medianLastCoverageInInterval ~ generalProjectCategory)

stat.test <- repos_data_with_coverage_info %>%
  group_by(loc_size) %>%
  wilcox_test(medianLastCoverageInInterval ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data_with_coverage_info %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianLastCoverageInInterval ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianLastCoverageInInterval ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

metric_summary <-
  summarise(group_by(repos_data_with_coverage_info, loc_size, generalProjectCategory), 
            projects = length(medianLastCoverageInInterval),
            min = min(medianLastCoverageInInterval, na.rm = TRUE),
            q1 = quantile(medianLastCoverageInInterval, probs = 0.25, na.rm = TRUE),
            median = median(medianLastCoverageInInterval, na.rm = TRUE),
            mean = mean(medianLastCoverageInInterval, na.rm = TRUE),
            q3 = quantile(medianLastCoverageInInterval, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(medianLastCoverageInInterval)$stats[5],
            max = max(medianLastCoverageInInterval, na.rm = TRUE))

# ----------------------------------------
# Visualization: bean plots 
# ----------------------------------------

par(xpd=F, mai = c(0.5, 0.8, 0.1, 0.1))

beanplot(medianLastCoverageInInterval ~ generalProjectCategory*loc_size, 
         data = repos_data_with_coverage_info %>% filter(!is.na(medianLastCoverageInInterval)), 
         ll = 0.08,
         # main = "beanplot", 
         what = c(0, 1, 1, 1),
         ylab = "Median Test Coverage", 
         side = "both",
         col = list("#F8766D", "#00BFC4"),
         beanlines = "median")

legend("bottomleft", fill = c("#F8766D", "#00BFC4"), legend = c("ML", "No ML"))

# ----------------------------------------
# Visualization: box plots with p-values
# ----------------------------------------

bxp <- ggboxplot(repos_data_with_coverage_info %>% filter(!is.na(medianLastCoverageInInterval)), x = "loc_size", y = "medianLastCoverageInInterval", 
                 # outlier.shape = NA,
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Median Test Coverage") +
  scale_y_continuous(
    limits = c(0, 115)
  ) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'p = {p}\nCliffs\' d = {cliffs_magnitude}',
                     bracket.nudge.y = 0.03) +
  geom_text(data = metric_summary, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) 

ggpar(bxp,legend = "right", legend.title = "Category")

############################################################################
# Applying the MWW test - Build/Run duration
############################################################################

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(medianRunDurationInMinutes ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianRunDurationInMinutes ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianRunDurationInMinutes ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

metric_summary <-
  summarise(group_by(repos_data, loc_size, generalProjectCategory), 
            projects = length(medianRunDurationInMinutes),
            min = min(medianRunDurationInMinutes, na.rm = TRUE),
            q1 = quantile(medianRunDurationInMinutes, probs = 0.25, na.rm = TRUE),
            median = median(medianRunDurationInMinutes, na.rm = TRUE),
            mean = mean(medianRunDurationInMinutes, na.rm = TRUE),
            q3 = quantile(medianRunDurationInMinutes, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(medianRunDurationInMinutes)$stats[5],
            max = max(medianRunDurationInMinutes, na.rm = TRUE))

# ----------------------------------------
# Visualization: bean plots 
# ----------------------------------------

par(xpd=F, mai = c(0.5, 0.8, 0.1, 0.1))

beanplot(medianRunDurationInMinutes ~ generalProjectCategory*loc_size, 
         data = repos_data %>% filter(!is.na(medianRunDurationInMinutes)), 
         ll = 0.08,
         # main = "beanplot", 
         what = c(0, 1, 1, 1),
         ylab = "Median Build Duration (Minutes)", 
         side = "both",
         log = "",
         col = list("#F8766D", "#00BFC4"),
         beanlines = "median")

legend("topleft", fill = c("#F8766D", "#00BFC4"), legend = c("ML", "No ML"))

# ----------------------------------------
# Visualization: box plots with p-values
# ----------------------------------------

bxp <- ggboxplot(repos_data %>% filter(!is.na(medianRunDurationInMinutes)), x = "loc_size", y = "medianRunDurationInMinutes", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Median Build Duration (Minutes)") +
  scale_y_continuous(
    # expand = c(0, 0),
    # breaks = seq(0, 1, by = 0.25),
    limits = c(0, 230)
  ) +
  stat_pvalue_manual(stat.test, hide.ns = FALSE, label = 'p = {p}\nCliffs\' d = {cliffs_magnitude}',
                     bracket.nudge.y = 0.03) +
  geom_text(data = metric_summary, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) 

ggpar(bxp,legend = "right", legend.title = "Category")

############################################################################
# Applying the MWW test - Commit Activity
############################################################################

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(medianCommitActivity ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianCommitActivity ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianCommitActivity ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

metric_summary <-
  summarise(group_by(repos_data, loc_size, generalProjectCategory), 
            projects = length(medianCommitActivity),
            min = min(medianCommitActivity, na.rm = TRUE),
            q1 = quantile(medianCommitActivity, probs = 0.25, na.rm = TRUE),
            median = median(medianCommitActivity, na.rm = TRUE),
            mean = mean(medianCommitActivity, na.rm = TRUE),
            q3 = quantile(medianCommitActivity, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(medianCommitActivity)$stats[5],
            max = max(medianCommitActivity, na.rm = TRUE))


# ----------------------------------------
# Visualization: bean plots 
# ----------------------------------------

par(xpd=F, mai = c(0.5, 0.8, 0.1, 0.1))

beanplot(medianCommitActivity ~ generalProjectCategory*loc_size, 
         data = repos_data %>% filter(!is.na(medianCommitActivity)), 
         ll = 0.08,
         # main = "beanplot", 
         what = c(0, 1, 1, 1),
         ylab = "Commit Activity", 
         side = "both",
         log = "",
         col = list("#F8766D", "#00BFC4"),
         beanlines = "median")

legend("topleft", fill = c("#F8766D", "#00BFC4"), legend = c("ML", "No ML"))


# ----------------------------------------
# Visualization: box plots with p-values
# ----------------------------------------

bxp <- ggboxplot(repos_data %>% filter(!is.na(medianCommitActivity)), x = "loc_size", y = "medianCommitActivity", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Commit Activity") +
  scale_y_continuous(
    expand = c(0, 0),
    breaks = seq(0, 1, by = 0.25),
    limits = c(0, 1.25)
  ) +
  stat_pvalue_manual(stat.test, hide.ns = FALSE, label = 'p = {p}\nCliffs\' d = {cliffs_magnitude}',
                     bracket.nudge.y = 0.03) +
  geom_text(data = metric_summary, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) 

ggpar(bxp,legend = "right", legend.title = "Category")
