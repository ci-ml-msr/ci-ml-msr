##############################################
########### IMPORTING PACKAGES  ##############
##############################################

library(dplyr)
library(jsonlite) 
library(openxlsx)
library(stringr)

###########################################################
# Define working directory
###########################################################

current_file_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(current_file_dir)

# set the datasets folder as the working directory
setwd('../datasets')

###########################################################
# Importing repository dataset
###########################################################

repos_data <- read.csv2("repositories-info_with_ci_metrics.csv", sep = ",", dec=".", na.strings = c('NULL'))

###########################################################
# Importing filtered pull requests dataset 
# -> Pull Requests with CI releated terms (i.e., CI, build, pipeline, workflow) in their comments
###########################################################

prs_with_ci_terms_data_file_name <- "qualitative-study-datasets/pulls-info-with-ci-terms-in-comments.xlsx"

if(file.exists(prs_with_ci_terms_data_file_name)){
  prs_with_ci_terms_data <- read.xlsx(prs_with_ci_terms_data_file_name, sheet = "prs_with_ci_terms_data")
}else{
  # Parse the cleaned JSON
  # unzip pulls-info-with-ci-terms-in-comments.json.zip first
  prs_with_ci_terms_json <- jsonlite::fromJSON("qualitative-study-datasets/pulls-info-with-ci-terms-in-comments.json")
  
  # Convert  the JSON data to dataframe 
  prs_with_ci_terms_data <- as.data.frame(prs_with_ci_terms_json) 
  
  # Adding the generalProjectCategory and loc_size columns from repository dataframe to the pull-request dataframe
  prs_with_ci_terms_data <- left_join(prs_with_ci_terms_data,
                                      repos_data %>% dplyr::select(fullName,
                                                                   loc_size,
                                                                   generalProjectCategory),
                                      by = "fullName")
  
  
  ###########################################################
  # prs_with_ci_terms_data as xlsx
  ###########################################################
  
  wb <- createWorkbook()
  
  # Add the data frames to different sheets in the workbook
  addWorksheet(wb, "prs_with_ci_terms_data")
  writeData(wb, sheet = 1, x = prs_with_ci_terms_data, startCol = 1, startRow = 1)
  
  # Save the workbook to an Excel file
  saveWorkbook(wb, "qualitative-study-datasets/pulls-info-with-ci-terms-in-comments.xlsx", overwrite = TRUE)
}

###########################################################
# Filtering out false positives (CI terms in bot comments)
# Consider only CI terms in comments of developers
###########################################################

get_authorlogin_from_comment <- function(comment){
  # Regular expression pattern to extract author login
  # pattern <- "authorLogin:\\s+(\\w+)"
  pattern <- "authorLogin:\\s+([^\n]+)"
  
  # Extract author login using str_match()
  match_result <- str_match(comment, pattern)
  
  # Extracted author login
  author_login <- match_result[1, 2]
  return(author_login)
}

extract_non_bot_commentsText_from_pull_request_commentsText <- function(commentsText){
  
  comment_spliter <- "-----------------------------------------\n"
  
  split_result <- strsplit(commentsText, comment_spliter)
  
  # Extract the first element of the resulting list (which is a character vector)
  comment_list <- split_result[[1]]
  
  bot_login_pattern <- "\\b(bot|ci|codecov|coveralls|github-actions|dependabot|bors|seldondev|appleboy|netlify|vercel|azure|pipeline(s)?)\\b"
  
  filtered_comments <- c()
  
  for(commentText in comment_list){
    
    # get the authorLogin from the commentbot_login_pattern regex
    authorlogin <- get_authorlogin_from_comment(commentText)
    
    isKnownBotLogin <- grepl(bot_login_pattern, authorlogin, ignore.case = FALSE)  
    
    # print(paste("author -->", authorlogin, " bot? ", isKnownBotLogin))
    
    # filter out comments with authorLogin matchin the 
    if (!isKnownBotLogin) {
      filtered_comments <- c(filtered_comments, commentText)  
    }
  }
  
  filtered_comments_text <- paste(filtered_comments, collapse = comment_spliter)
  
  return(filtered_comments_text)
}

has_ci_related_terms_in_non_bot_comments <- function(commentsText){
  
  ci_related_terms_pattern <- "\\b(ci|continuous integration|devops|dev ops|workflow(s)?|build(?:s|ing)?|pipeline(s)?)\\b"
  
  non_bot_commentsText <- extract_non_bot_commentsText_from_pull_request_commentsText(commentsText)
  
  has_ci_ralted_terms_in_non_bot_comments <- grepl(ci_related_terms_pattern, non_bot_commentsText, ignore.case = FALSE)
  
  return(has_ci_ralted_terms_in_non_bot_comments)
}

filtered_prs_with_ci_terms_data <- data.frame()
for(row_index in 1:nrow(prs_with_ci_terms_data)){
  print(paste(row_index, "/", nrow(prs_with_ci_terms_data)))
  pull <- prs_with_ci_terms_data[row_index, ]
  if(has_ci_related_terms_in_non_bot_comments(pull$comments)){
    filtered_prs_with_ci_terms_data <- rbind(filtered_prs_with_ci_terms_data, pull)
  }
}

prs_with_ci_terms_data <- filtered_prs_with_ci_terms_data

summarise(group_by(prs_with_ci_terms_data, generalProjectCategory),
          pull_requests = length(generalProjectCategory))

###########################################################
# Sample size calculation
# https://www.surveymonkey.com/mp/sample-size-calculator/
###########################################################

# Function to calculate sample size for proportion estimation with known population size
calculate_sample_size <- function(N, confidence_level, E, p = 0.5) {
  # N = population size
  # E = Margin of error 
  # p = Sample proportion
  # NOTE: estimated proportion (p): We use 0.5 as a conservative approach, and it will give the largest possible sample size.
  Z <- qnorm(1 - (1 - confidence_level) / 2)  # Z-score for a 95% confidence level
  p <-   # Example estimated proportion (0.5 for maximum uncertainty)
    n <- (N * Z^2 * p * (1 - p)) / ((N - 1) * E^2 + Z^2 * p * (1 - p))
  return(ceiling(n))  # Round up to the nearest whole number because sample size must be an integer
}

# Create the strata (based on the project category)
strata <- c("ML", "No ML")

stratified_sample_df <- data.frame()

# Calculate the sample size for each stratum (ML and No ML)
# Randomly select the pull_requests that will compose the sample  
for (i in 1:length(strata)) {
  stratum <- strata[i]
  stratum_pull_requests <- which(prs_with_ci_terms_data$generalProjectCategory == stratum)
  stratum_size <- length(stratum_pull_requests)
  
  # Calculate the sample size for the current stratum 
  stratum_sample_size <- calculate_sample_size(stratum_size, confidence_level = 0.95, E=0.05)
  
  stratum_projects <- unique(prs_with_ci_terms_data[stratum_pull_requests,]$fullName)
  
  selected_pull_requests_per_stratum_index <- c()
  
  # Perform stratified sampling for each projects of each stratum (ML and non-ML groups)
  # Keeps the proportion based on the population (N)
  # Set a seed for reproducibility
  set.seed(42)
  for (i in 1:length(stratum_projects)) {
    project <- stratum_projects[i]
    project_pull_requests <- prs_with_ci_terms_data[prs_with_ci_terms_data$fullName == project,]
    project_pull_requests_size <- nrow(project_pull_requests)
    coded_project_prs <- data.frame()
    
    proportion <- project_pull_requests_size / stratum_size 
    
    project_sample_size <- round(proportion * stratum_sample_size)
    
    # If the project has more pull_requests than needed for the sample
    if (nrow(project_pull_requests) > project_sample_size) {
      stratified_sample_df <- rbind(stratified_sample_df, project_pull_requests[sample(nrow(project_pull_requests), project_sample_size),])
    } else {
      # If the project has fewer pull_requests than needed, include all and move to the next stratum
      stratified_sample_df <- rbind(stratified_sample_df, project_pull_requests)
    }
  }
  
  selected_pull_requests_per_stratum_size <- nrow(stratified_sample_df[stratified_sample_df$generalProjectCategory == stratum,])
  
  if(selected_pull_requests_per_stratum_size < stratum_sample_size){
    
    lacking_prs_in_stratum_sample_count <- stratum_sample_size - selected_pull_requests_per_stratum_size
    
    stratum_pull_requests_not_selected <- prs_with_ci_terms_data[prs_with_ci_terms_data$generalProjectCategory == stratum & !(prs_with_ci_terms_data$id %in% stratified_sample_df$id),]
    
    stratified_sample_df <- rbind(stratified_sample_df, stratum_pull_requests_not_selected[sample(nrow(stratum_pull_requests_not_selected), lacking_prs_in_stratum_sample_count),])
  }
}

nrow(stratified_sample_df)

# Filter the stratified pull_requests sample (ML and no ML)
ml_pull_requests <- stratified_sample_df[stratified_sample_df$generalProjectCategory == 'ML',]
no_ml_pull_requests <- stratified_sample_df[stratified_sample_df$generalProjectCategory == 'No ML',]

###########################################################
# Getting the totals of pull requests in the stratified sample
###########################################################

total_ml_pull_requests_count <- nrow(filtered_prs_with_ci_terms_data[filtered_prs_with_ci_terms_data$generalProjectCategory == 'ML',])
total_no_ml_pull_requests_count <- nrow(filtered_prs_with_ci_terms_data[filtered_prs_with_ci_terms_data$generalProjectCategory == 'No ML',])

stratified_ml_pull_requests_count <- nrow(ml_pull_requests)
stratified_no_ml_pull_requests_count <- nrow(no_ml_pull_requests)

# total pull requests with CI related words in comments -> 11549
# total ML pull requests -> 7062
# total No ML pull requests -> 4487

# stratified ML pull requests -> 365
# stratified No ML pull requests -> 354
# stratified sample -> 719

###########################################################
# Export the Stratified Random Sample (SRS) 
###########################################################

# wb <- createWorkbook()
# 
# # Add the data frames to different sheets in the workbook
# addWorksheet(wb, "ml")
# writeData(wb, sheet = 1, x = ml_pull_requests, startCol = 1, startRow = 1)
# 
# addWorksheet(wb, "no_ml")
# writeData(wb, sheet = 2, x = no_ml_pull_requests, startCol = 1, startRow = 1)
# 
# # Save the workbook to an Excel file
# saveWorkbook(wb, "qualitative-study-datasets/stratified_prs_sample_v4.xlsx", overwrite = TRUE)