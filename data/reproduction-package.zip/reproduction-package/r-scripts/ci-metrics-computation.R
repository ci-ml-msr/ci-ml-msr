library(datetime)
library(lubridate)
library(sqldf)
library(ggplot2)
library(rtern)
library(beanplot)
library(effsize)
library(tidyverse)
library(dplyr)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(data.table)
library(grid)
library(gridExtra)
library(changepoint)

###########################################################
# Define work directory
###########################################################

current_file_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(current_file_dir)

# set the datasets folder as the working directory
setwd('../datasets')

###########################################################
# Import repository dataset
###########################################################

repos_data <- read.csv2("repositories-info.csv", sep = ",", dec=".", na.strings = c('NULL'))

# View(repos_data)

###########################################################
# Define the project size based on their lines of codes
###########################################################

repos_data['loc_size'] <- NA
repos_data[repos_data$lines_of_code <= 10000, 'loc_size'] <- 'small'
repos_data[repos_data$lines_of_code >  10000   & repos_data$lines_of_code <=  100000, 'loc_size'] <- 'medium'
repos_data[repos_data$lines_of_code >  100000, 'loc_size'] <- 'large'

# Define the order of the boxes
box_order <- c("ML", "No ML")

# Define the order of the boxes
loc_size_box_order <- c("small", "medium", "large")

# Reorder the factor levels
repos_data$generalProjectCategory <- reorder(repos_data$generalProjectCategory, 
                                             as.numeric(factor(repos_data$generalProjectCategory, 
                                                               levels = box_order)))

# Reorder the factor levels
repos_data$loc_size <- reorder(repos_data$loc_size, 
                               as.numeric(factor(repos_data$loc_size, 
                                                 levels = loc_size_box_order)))

# --------------------------------------------------------------------------
# Summarize repositories count by generalProjectCategory and loc_size
# --------------------------------------------------------------------------

# number of repositories per category (AI-ML, No AI-ML)
sqldf("select generalProjectCategory category, count(*) projects_count
            from repos_data repos
            group by generalProjectCategory
            ")

# number of repositories per category (AI-ML, No AI-ML) 
sqldf("select generalProjectCategory category, isOutOfMLDataset, count(*) projects_count
            from repos_data repos
            group by generalProjectCategory, isOutOfMLDataset
            ")

# number of repositories per category and size
sqldf("select generalProjectCategory AS category, loc_size, count(*) projects_count
      from repos_data repos
      group by generalProjectCategory, loc_size
      order by loc_size
      ")

# number of repositories per category and programming language 
sqldf("select generalProjectCategory, language, count(*) projects_count
      from repos_data repos
      group by generalProjectCategory, language
      ORDER BY generalProjectCategory, projects_count DESC
      ")

###########################################################
# Import commits dataset
###########################################################

# The commits dataset has some fields with double quotes within them.
# The read.CSV function doesn't deal with this specific format
# We have to replace the double quotes before reading the data

lines <- readLines("commits-info.csv")
lines <- gsub('(?<!,)"(?!,)', '', lines, perl = TRUE)

commits_data <- read.csv2(textConnection(lines), sep = ",", na.strings = c('NULL'))
commits_data <- commits_data[commits_data$fullName %in% unique(repos_data$fullName),]

commits_data$weekDay <- lubridate::wday(commits_data$authorDate, label = TRUE, abbr = FALSE)
commits_data$weekDayNumber <- lubridate::wday(commits_data$authorDate, week_start = 1)
commits_data$month <- lubridate::month(commits_data$authorDate, label = TRUE, abbr = FALSE)

# It is neccessary to change commiterDate class from POSIXlt to character
# because sqldf function does not support datatables with POSIXlt columns
commits_data$committerDate <- as.character(commits_data$committerDate)
commits_data$authorDate <- as.character(commits_data$authorDate)

###########################################################
## Import GHA run dataset
###########################################################

# import GHA run dataset with time to fix metric calculated
# if the time to fix is not calculated, then calculate

gha_runs_data_time_to_fix_file_name <- "gha-runs-info_time-to-fix-calculated.csv"

if(file.exists(gha_runs_data_time_to_fix_file_name)){
  gha_runs_data <- read.csv2(gha_runs_data_time_to_fix_file_name, sep = ",", dec=".", na.strings = c('NULL'))
}else{
  gha_runs_data <- read.csv2("gha-runs-info.csv", sep = ",", dec=".", na.strings = c('NULL'))
  
  # filter out workflow run duration higher than 35 days, the limit defined by GH
  # https://docs.github.com/en/actions/learn-github-actions/usage-limits-billing-and-administration
  
  gha_runs_data <- gha_runs_data[difftime(gha_runs_data$updatedAt,
                                          gha_runs_data$run_started_at, 
                                          units = "days") <= 35,]
  
  ## calculate the time to fix broken runs by repository
  calculateTimeToFixBrokenRunByRepos <- function(workflowRuns){
    
    workflowRuns <- workflowRuns[order(workflowRuns$workflow_id, workflowRuns$updatedAt),]
    
    workflowRuns$fixedBy <- NA
    workflowRuns$fixedAt <- NA
    workflowRuns$timeToFix <- NA
    
    if(nrow(workflowRuns) != 0){
      failed_run_date <- NA
      failed_run <- NA
      failed_run_index <- NA
      current_wokflow_id <- workflowRuns[1,]$workflow_id
      
      for(i in 1:nrow(workflowRuns)){
        run <- workflowRuns[i,]
        
        if(current_wokflow_id != run$workflow_id){
          failed_run_date <- NA
          failed_run <- NA
          failed_run_index <- NA
          current_wokflow_id <- run$workflow_id
        }
        
        if(is.na(failed_run_date) && run$conclusion %in% c("failure")){
          failed_run_date <- run$updatedAt
          failed_run_index <- i
          # print(paste("Failed Run date: ", failed_run_date))
        }
        if(!is.na(failed_run_date) && run$conclusion == "success"){
          passed_run_date <- run$updatedAt
          time_to_fix_run <- as.numeric(difftime(passed_run_date, failed_run_date, units = "hours")) / 24 # in days
          failed_run_date <- NA
          workflowRuns[failed_run_index,]$fixedBy <- run$ghId
          workflowRuns[failed_run_index,]$fixedAt <- run$updatedAt
          workflowRuns[failed_run_index,]$timeToFix <- time_to_fix_run
        }
      }
    }
    return(workflowRuns)
  }
  
  # calculate the time to fix broken runs for all repositories
  calculateTimeToFixBrokenRunAllRepos <- function(runs){
    runs_aux = data.frame()
    runs_colnames <- NA
    for(proj in unique(runs$fullName)){
      proj_runs <- runs[runs$fullName == proj,]
      proj_runs <- calculateTimeToFixBrokenRunByRepos(proj_runs)
      runs_aux <- rbind(runs_aux, proj_runs)
      runs_colnames <- names(runs_aux)
    }
    colnames(runs_aux) <- runs_colnames
    return(runs_aux)
  }
  
  ## adding the time to fix broken run for each studied project
  
  gha_runs_data <- calculateTimeToFixBrokenRunAllRepos(gha_runs_data)
  gha_runs_data$timeToFixInHours <- gha_runs_data$timeToFix * 24
  
  write.csv(gha_runs_data, file = "gha-runs-info_time-to-fix-calculated.csv", row.names = FALSE, sep = ",", dec = ".", na = c('NULL'))  
}

###########################################################
## Importing Coverage info - From coveralls and CodeCov
###########################################################

coverage_data <- read.csv2("coverage-info.csv", sep = ",", dec=".", na.strings = c('NULL'))

###########################################################
## Importing Pull Requests info
###########################################################

# Parse the cleaned JSON
# pulls_data_json <- jsonlite::fromJSON("pulls-info.json")
# 
# # Convert the JSON data to dataframe 
# pulls_data <- as.data.frame(pulls_data_json) 

pulls_data <- read.csv2("pulls-info.csv", sep = ",", dec=".", na.strings = c('NULL'))

pulls_data$isDraft <- as.logical(as.numeric(pulls_data$isDraft))
pulls_data$locked <- as.logical(as.numeric(pulls_data$locked))
pulls_data$mergeable <- as.logical(as.numeric(pulls_data$mergeable))
pulls_data$merged <- as.logical(as.numeric(pulls_data$merged))

pulls_data$mergeTimeInHours <- round(difftime(as.POSIXct(pulls_data$mergedAt), as.POSIXct(pulls_data$createdAt), units = "hours"), digits = 2)
pulls_data$mergeTimeInDays <- round(difftime(as.POSIXct(pulls_data$mergedAt), as.POSIXct(pulls_data$createdAt), units = "days"), digits = 3)


###########################################################
## Summaryzing projects general information
###########################################################

pulls_per_project <- summarise(
  group_by(pulls_data, fullName),
  pull_requests = length(fullName))

coverage_per_project <- summarise(
  group_by(coverage_data, fullName),
  coverage_builds = length(fullName))

commits_per_project <- summarise(
  group_by(commits_data, fullName),
  commits = length(fullName))

ghruns_per_project <- summarise(
  group_by(gha_runs_data, fullName),
  ci_builds = length(fullName))


# Add the repository general info (i.e., count the number of pulls per project) to the repository dataset
repos_data <- left_join(repos_data,
                        pulls_per_project %>% dplyr::select(fullName,
                                                            pull_requests),
                        by = "fullName")


repos_data <- left_join(repos_data,
                        coverage_per_project %>% dplyr::select(fullName,
                                                               coverage_builds),
                        by = "fullName")

repos_data <- left_join(repos_data,
                        commits_per_project %>% dplyr::select(fullName,
                                                              commits),
                        by = "fullName")

repos_data <- left_join(repos_data,
                        ghruns_per_project %>% dplyr::select(fullName,
                                                             ci_builds),
                        by = "fullName")

# Calculate the project age based on the creation_at attribute of the project and the date when the search was done in GitHub
date_of_github_search <- as.Date("2023-06-02")
repos_data$ageInYear <- as.numeric(round(difftime(as.POSIXct(date_of_github_search), as.POSIXct(repos_data$created_at), units = "days") / 365, 1))

summarise(group_by(repos_data, loc_size, generalProjectCategory),
          projects = length(loc_size),
          forks = median(forks, na.rm = TRUE),
          watchers = median(watchers, na.rm = TRUE),
          medianAgeYears = median(ageInYear),
          coverage_builds = sum(coverage_builds, na.rm = TRUE),
          pull_requests = sum(pull_requests),
          commits = sum(commits),
          ci_builds = sum(ci_builds),
)

summarise(group_by(repos_data, generalProjectCategory),
          medianAgeYears = median(ageInYear),
          medianForks = median(forks, na.rm = TRUE),
          medianWatchers = median(watchers, na.rm = TRUE),
)

###########################################################
#
# Calculate monthly intervals by project
#
###########################################################

# --------------------------------------------------------------------------
# Declaration of functions used to measure information to the monthly intervals of the projects 
# --------------------------------------------------------------------------

## This function calculate the number of occurrences of weekend days in a date interval
countWeekendDaysInInterval <- function(start_date, end_date){
  myDates <-seq(from = start_date, to = end_date, by = "days")
  weekdays <- c("Saturday", "Sunday")
  return(length(which(lubridate::wday(myDates, label = TRUE, abbr = FALSE) %in% weekdays)))
}

## This function counts the different commiters that commited to a set of commits
countAuthorsInCommits <- function(commits_data){
  authorsCount <- 0
  if(nrow(commits_data) > 0){
    authors <- unique(commits_data$authorEmail)  
    authors <- authors[!authors == 'noreply@github.com']
    authorsCount <- length(authors)
  }
  return(authorsCount)
}

## This function gets the last code coverage information available in a set of coverages of a date interval
lastCoverageInIntervalMetric <- function(coverages){
  coverages <- coverages[!is.na(coverages$covered_percent),]
  sortedCoveragesInInterval <- coverages[order(coverages$created_at), ]
  if(nrow(sortedCoveragesInInterval) > 0){
    return(sortedCoveragesInInterval[nrow(sortedCoveragesInInterval),]$covered_percent)  
  }
  return(NA)
}

## This function calculates the Commit Activity Metric 
# Commit Activity Metric is a unit interval representing the rate of commits across days. 
# If commits were made every day in a period (1 month), the value would be 1. 
# If commits were made in half of days the value would be 0.5. 
# If there were no commits in a period the value would be 0.
calculateCommitActivityMetric <- function(commits, start_date, end_date, excludeWeekendDays=FALSE){
  dates <- seq(from = start_date, to = end_date, by = "days")
  days_in_interval = length(dates)
  if(excludeWeekendDays){
    weekendDaysInInterval <- countWeekendDaysInInterval(start_date, end_date)
    days_in_interval <- days_in_interval - weekendDaysInInterval
  }
  days_with_commits <- length(unique(as.Date(commits$committerDate)))
  if(days_in_interval > 0){
    return(days_with_commits / days_in_interval)  
  }
  return(NA)
}

## This function calculates the Build Health Metric 
# Build Health is a unit interval representing the rate of build failures across days. 
# If there were build failures every day, the value would be 0. 
# if there were no build failures, the value would be 1.
calculateRunsHealthMetric <- function(runsInInterval, start_date, end_date, excludeWeekendDays=FALSE){
  dates <- seq(from = start_date, to = end_date, by = "days")
  days_in_interval = length(dates)
  if(excludeWeekendDays){
    weekendDaysInInterval <- countWeekendDaysInInterval(start_date, end_date)
    days_in_interval <- days_in_interval - weekendDaysInInterval
  }
  days_with_failed_builds <- length(unique(as.Date(runsInInterval[runsInInterval$conclusion == "failure",]$createdAt)))
  if(days_in_interval > 0){
    return(1 - days_with_failed_builds / days_in_interval)  
  }
  return(NA)
}

## This function calculates the Build Health Metric 
# Build Health is a unit interval representing the rate of build failures across days that had builds. 
# If there were build failures every day that a build was triggered, the value would be 0. 
# if there were no build failures, the value would be 1.
calculateRunsHealthMetricAdapted <- function(runsInInterval, start_date, end_date){
  days_with_builds <- length(unique(as.Date(runsInInterval$createdAt)))
  days_with_failed_builds <- length(unique(as.Date(runsInInterval[runsInInterval$conclusion == "failure",]$createdAt)))
  if(days_with_builds > 0){
    return(1 - days_with_failed_builds / days_with_builds)  
  }
  return(NA)
}

## This function calculates the Runs Activity Metric 
# Runs Activity is a unit interval (i.e., a closed interval [0,1]) representing the rate of runs across days, 
# i.e, if runs were made every day in the period of analysis, the value would be 1. 
# If runs were made in half of the days, the value would be 0.5. 
# If there were no runs, the value would be 0.
calculateRunsActivityMetric <- function(runsInInterval, start_date, end_date, excludeWeekendDays=FALSE){
  dates <- seq(from = start_date, to = end_date, by = "days")
  days_in_interval = length(dates)
  if(excludeWeekendDays){
    weekendDaysInInterval <- countWeekendDaysInInterval(start_date, end_date)
    days_in_interval <- days_in_interval - weekendDaysInInterval
  }
  days_with_builds <- length(unique(as.Date(runsInInterval$createdAt)))
  if(days_in_interval > 0){
    return(days_with_builds / days_in_interval)  
  }
  return(NA)
}

# --------------------------------------------------------------------------
# calculating the monthly interval for the studied projects
# --------------------------------------------------------------------------

repos_month_date_intervals <- data.frame()

repos_data$monthlyIntervals <- NA
interval_lenght_in_days <- 30
for(proj in unique(repos_data$fullName)){
  
  # getting the project specific data (first and last GHA Run)
  projData <- repos_data[repos_data$fullName == proj,]
  loc_size <- projData$loc_size
  generalProjectCategory <- projData$generalProjectCategory
  
  # getting the project specific data (commits and workflowsRuns)
  projCommitsData <- commits_data[commits_data$fullName == proj,]
  projRunsData <- gha_runs_data[gha_runs_data$fullName == proj,]
  projCoverageData <- coverage_data[coverage_data$fullName == proj,]
  projPullsData <- pulls_data[pulls_data$fullName == proj,]
  # projWorkflowFileChangeData <- workflow_file_change_data[workflow_file_change_data$fullName == proj,]
  
  firstCIWorkflowRunAt <- as.Date(min(projRunsData$createdAt))
  lastCIWorkflowRunAt <- as.Date(max(projRunsData$createdAt))
  
  start_date <- firstCIWorkflowRunAt
  
  monthIntervals <- 0
  ## start
  while(start_date + days(interval_lenght_in_days - 1) < lastCIWorkflowRunAt){
    end_date <- start_date + days(interval_lenght_in_days - 1)
    print(sprintf("Proj: %s - Start date: %s - End date: %s", proj, start_date, end_date))
    
    commitsInInterval <- projCommitsData[as.Date(projCommitsData$committerDate) >= start_date &
                                           as.Date(projCommitsData$committerDate) <= end_date,]
    
    runsInInterval <- projRunsData[as.Date(projRunsData$createdAt) >= start_date &
                                     as.Date(projRunsData$createdAt) <= end_date,]
    
    successfullyRunsInInterval <- runsInInterval[runsInInterval$conclusion %in% c("success"),]
    
    successfullyRunsInIntervalCount <- nrow(successfullyRunsInInterval)
    
    failedRunsInIntervalCount <- nrow(runsInInterval[runsInInterval$conclusion %in% c("failure"),])
    
    successfulAndFailedRunsInInterval <- runsInInterval[runsInInterval$conclusion %in% c("success", "failure"),]
    
    otherRunsInIntervalCount <- nrow(runsInInterval[!(runsInInterval$conclusion %in% c("success", "failure")),])
    
    coverageInInterval <- projCoverageData[as.Date(projCoverageData$created_at) >= start_date &
                                             as.Date(projCoverageData$created_at) <= end_date,]
    
    fixed_runsInInterval <- runsInInterval[!is.na(runsInInterval$timeToFixInHours),]
    
    runsInIntervalCount <- nrow(runsInInterval)
    fixedRunsInInterval <- nrow(fixed_runsInInterval)
    coverageBuildsInInterval <- nrow(coverageInInterval)
    
    noNARunDurations <- runsInInterval[!is.na(runsInInterval$duration) & runsInInterval$duration >= 0,]$duration
    
    medianRunDurationInMinutes <- NA
    medianTimeToFixRunsInHours <- NA
    runsHealth <- NA
    
    runsActivity <- calculateRunsActivityMetric(runsInInterval, start_date, end_date)
    
    if(nrow(successfulAndFailedRunsInInterval) > 0){
      runsHealth <- calculateRunsHealthMetricAdapted(successfulAndFailedRunsInInterval, start_date, end_date)
    }
    
    if(successfullyRunsInIntervalCount > 0){
      medianRunDurationInMinutes <- median(successfullyRunsInInterval$duration) / 60
    }
    
    if(fixedRunsInInterval > 0){
      medianTimeToFixRunsInHours <- median(fixed_runsInInterval$timeToFixInHours)
    }
    
    commitsCount <- nrow(commitsInInterval)
    
    weekendDaysInInterval <- countWeekendDaysInInterval(start_date, end_date)
    
    authors <- countAuthorsInCommits(commitsInInterval)
    
    commitRatePerDay <- NA
    commitRateExcludingWeekendDays <- NA
    commitsPerAuthor <- NA
    commitActivity <- NA
    
    # if(commitsCount > 0){
    commitRatePerDay <- commitsCount / interval_lenght_in_days
    commitRatePerDayExcludingWeekendDays <- commitsCount / (interval_lenght_in_days - weekendDaysInInterval)
    commitsPerAuthor <- commitsCount / authors
    commitActivity <- calculateCommitActivityMetric(commitsInInterval, start_date, end_date)
    # }
    
    lastCoverageInInterval <- NA
    if(coverageBuildsInInterval > 0){
      lastCoverageInInterval <- lastCoverageInIntervalMetric(coverageInInterval)
    }
    
    submitedPRs_df <- projPullsData[as.Date(projPullsData$createdAt) >= start_date &
                                    as.Date(projPullsData$createdAt) <= end_date,]
    
    submitedPRs <- nrow(submitedPRs_df)
    
    mergedPRs_df <- projPullsData[projPullsData$merged &
                                  projPullsData$mergedAt >= start_date &
                                  projPullsData$mergedAt <= end_date,]
    
    mergedPRs <- nrow(mergedPRs_df)
    
    rejectedPRs_df <- projPullsData[!is.na(projPullsData$closedAt) &
                                    projPullsData$closedAt >= start_date &
                                    projPullsData$closedAt <= end_date &
                                    projPullsData$merged == FALSE,]
    
    rejectedPRs <- nrow(rejectedPRs_df)
    
    pullRequestContributors <- length(unique(submitedPRs_df$authorLogin))
    
    medianPRChurn <- median(submitedPRs_df$additions + submitedPRs_df$deletions)
    medianPRChangedFiles <- median(submitedPRs_df$changedFiles)
    medianPRCommits <- median(submitedPRs_df$commitsCount)
    medianPRMergeTimeInDays <- median(mergedPRs_df$mergeTimeInDays)
    medianPRRejectTimeInDays <- median(round(difftime(as.POSIXct(rejectedPRs_df$closedAt), as.POSIXct(rejectedPRs_df$createdAt), units = "days"), digits = 3))
    
    intervalOrder <- monthIntervals + 1
    
    interval <- data.frame(proj, loc_size, generalProjectCategory,
                           intervalOrder,
                           start_date, end_date, 
                           commitsCount, authors, weekendDaysInInterval,
                           commitRatePerDay, commitRatePerDayExcludingWeekendDays,
                           commitsPerAuthor,
                           commitActivity,
                           runsActivity,
                           runsInIntervalCount,
                           successfullyRunsInIntervalCount,
                           failedRunsInIntervalCount, 
                           otherRunsInIntervalCount,
                           medianRunDurationInMinutes,
                           fixedRunsInInterval,
                           medianTimeToFixRunsInHours,
                           runsHealth,
                           lastCoverageInInterval,
                           submitedPRs,
                           mergedPRs,
                           rejectedPRs,
                           pullRequestContributors,
                           medianPRChurn,
                           medianPRChangedFiles,
                           medianPRCommits,
                           medianPRMergeTimeInDays,
                           medianPRRejectTimeInDays
    )
    repos_month_date_intervals <- rbind(repos_month_date_intervals, interval)
    
    start_date <- end_date + days(1)
    monthIntervals  <- monthIntervals + 1
  }
  
  repos_data[repos_data$fullName == proj, 'monthlyIntervals'] <- monthIntervals
}

# -----------------------------
# Calculating the difference in percentage of the monthly changes in medianRunDurationInMinutes
# for the studied projects

repos_month_date_intervals <- repos_month_date_intervals %>%
  arrange(proj, intervalOrder) %>%
  group_by(proj) %>%
  mutate(Last_Non_Null_Value = zoo::na.locf(lag(medianRunDurationInMinutes), na.rm = FALSE, fromLast = FALSE)) %>%
  mutate(Percentage_Difference = ifelse(is.na(Last_Non_Null_Value), NA, (medianRunDurationInMinutes - Last_Non_Null_Value) / Last_Non_Null_Value * 100)) %>%
  select(-c(medianRunDurationInMinutes), everything(), medianRunDurationInMinutes, Last_Non_Null_Value, Percentage_Difference)


repos_month_date_intervals_filename <- "repos_month_date_intervals.csv"
write.csv(repos_month_date_intervals[, -which(names(repos_month_date_intervals) %in% c("Last_Non_Null_Value", "X", "X.1"))], file = repos_month_date_intervals_filename, row.names = TRUE, na = c('NULL'))

# Define the order of the boxes
loc_size_box_order <- c("small", "medium", "large")
box_order <- c("ML", "No ML")

# Reorder the factor levels
repos_month_date_intervals$loc_size <- reorder(repos_month_date_intervals$loc_size, as.numeric(factor(repos_month_date_intervals$loc_size, levels = loc_size_box_order)))
repos_month_date_intervals$generalProjectCategory <- reorder(repos_month_date_intervals$generalProjectCategory, as.numeric(factor(repos_month_date_intervals$generalProjectCategory, levels = box_order)))

###############################################################################
#
# ADDING THE MEDIAN VALUES FOR THE CI METRICS TO THE REPOSITORY DATASET
#
###############################################################################

repos_ci_metrics_median <-
  summarise(group_by(repos_month_date_intervals, proj), 
            medianCommitActivity = median(commitActivity, na.rm = TRUE),
            medianCommitRatePerDay = median(commitRatePerDay, na.rm = TRUE),
            medianLastCoverageInInterval = median(lastCoverageInInterval, na.rm = TRUE),
            medianTimeToFixRunsInHours = median(medianTimeToFixRunsInHours, na.rm = TRUE),
            medianRunDurationInMinutes = median(medianRunDurationInMinutes, na.rm = TRUE))

names(repos_ci_metrics_median)[1] <- "fullName"

## Adding the repos_ci_metrics columns to the repos_data dataset
repos_data <- left_join(repos_data,
                        repos_ci_metrics_median,
                        by = "fullName")


write.csv(repos_data, file = "repositories-info_with_ci_metrics.csv", row.names = FALSE, na = c('NULL'))

View(repos_data)
View(repos_month_date_intervals)


###############################################################################
# TIME SERIES ANALYSIS FOR medianRunDurationInMinutes
###############################################################################

repos_data$medianRunDurationInMinFirstMonth <- NA
repos_data$medianRunDurationInMinLastMonth <- NA
repos_data$diffInFirstAndLastMonth <- NA
repos_data$diffInPercentage <- NA
repos_data$abrupt_changes <- NA
repos_data$abrupt_increases <- NA
repos_data$abrupt_decreases <- NA

repos_data$abruptDecreaseRatePerYear <- NA
repos_data$abruptIncreaseRatePerYear <- NA
repos_data$abruptChangesRatePerYear <- NA

projCount <- 0
for(fullName in unique(repos_month_date_intervals$proj)){
  projData <- repos_month_date_intervals %>% filter(proj == fullName & !is.na(medianRunDurationInMinutes))
  
  projCount <- projCount + 1
  
  print(sprintf("#%s Proj: %s - %s %s", projCount, projData$proj, projData$generalProjectCategory, projData$loc_size))
  
  # ----------------------------------------------------------------
  # Detect change points in medianRunDuration
  # ----------------------------------------------------------------
  
  variables <- c("start_date", "medianRunDurationInMinutes")
  
  ts_data <- projData[!is.na(projData$medianRunDurationInMinutes), variables]
  
  cpt_result <- NA
  change_points <- NA
  tryChangePointIdentification <- TRUE
  q_value <- NA
  while(tryChangePointIdentification){
    # Use tryCatch to capture and read the error message
    tryCatch({
      if(is.na(q_value)){
        cpt_result <<- cpt.mean(ts_data$medianRunDurationInMinutes, method = 'BinSeg')  
      }else{
        print(paste('changepoint::cpt.mean with Q =', q_value))
        cpt_result <<- cpt.mean(ts_data$medianRunDurationInMinutes, method = 'BinSeg', Q = q_value)
        print("changepoint::cpt.mean was executed successfuly!")
      }
      change_points <<- cpts(cpt_result)
      tryChangePointIdentification <<- FALSE
      q_value <<- NA
    }, error = function(e) {
      error_message <- conditionMessage(e)
      
      print(paste("ERROR:", error_message))
      
      # Define the regex pattern to match the number of segments
      pattern <- "Q is larger than the maximum number of segments (\\d+)"
      
      # If there are no meaningful changes in your data, you may not get any change points detected
      pattern2 <- "Minimum segment legnth is too large to include a change in this data"
      
      # Use regex to extract the number of segments
      matches <- str_match(error_message, pattern)
      
      # Check if a match is found
      if (!is.na(matches[2])) {
        num_segments <- as.numeric(matches[2])
        q_value <<- num_segments - 1
      } else {
        if (error_message == pattern2){
          cat("There are no meaningful changes in the data.\n")  
        }else{
          cat("No match found for the number of segments.\n")
        }
        q_value <<- NA
        change_points <<- NA
        cpt_result <<- NA
        tryChangePointIdentification <<- FALSE
      }
    })
  }
  
  column_names <- c("yintercept", "xmin", "xmax")
  hlines_df <- data.frame(matrix(nrow = 0, ncol = length(column_names)))
  colnames(hlines_df) <- column_names
  
  # Split the time series into segments based on the change points
  if(!is.na(change_points) && length(change_points) > 0){
    for (i in 1:(length(change_points) + 1)) {
      if (i == 1) {
        segmentIndices <- 1:change_points[i]
      } else if (i == length(change_points) + 1) {
        segmentIndices <- (change_points[i - 1] + 1):nrow(ts_data)
      } else {
        segmentIndices <- (change_points[i - 1] + 1):change_points[i]
      }
      segment <- ts_data[segmentIndices,]$medianRunDurationInMinutes
      
      projSegmentData <- ts_data[segmentIndices,]
      segmentMedianRunDurationInMinutes <- projSegmentData$medianRunDurationInMinutes
      yintercept <- mean(segmentMedianRunDurationInMinutes)
      # print(segmentIndices)
      # print(segment)
      hlines_df_row <- data.frame(yintercept = yintercept,
                                  xmin = min(projSegmentData$start_date),
                                  xmax = max(projSegmentData$start_date))
      hlines_df <- rbind(hlines_df, hlines_df_row)
    }  
  }  
  
  # Loop through the breakpoint segments to assess the direction of each segment
  abrupt_increases <- 0
  abrupt_decreases <- 0
  if(nrow(hlines_df) >= 2){
    for(i in 1:(nrow(hlines_df) - 1)){
      if(hlines_df[i,]$yintercept > hlines_df[i + 1,]$yintercept){
        abrupt_decreases <- abrupt_decreases + 1
      }else{
        abrupt_increases <- abrupt_increases + 1
      }
    }  
  }
  
  medianRunDurationInMinFirstMonth <- round(ts_data[1,]$medianRunDurationInMinutes, 2)
  medianRunDurationInMinLastMonth <- round(ts_data[nrow(ts_data),]$medianRunDurationInMinutes, 2)
  diffInFirstAndLastMonth <- round(medianRunDurationInMinLastMonth - medianRunDurationInMinFirstMonth, 2)
  diffInPercentage <- round(diffInFirstAndLastMonth / medianRunDurationInMinFirstMonth  * 100, 2)
  
  repos_data[repos_data$fullName == fullName, 'medianRunDurationInMinFirstMonth'] <- medianRunDurationInMinFirstMonth
  repos_data[repos_data$fullName == fullName, 'medianRunDurationInMinLastMonth'] <- medianRunDurationInMinLastMonth
  repos_data[repos_data$fullName == fullName, 'diffInFirstAndLastMonth'] <- diffInFirstAndLastMonth
  repos_data[repos_data$fullName == fullName, 'diffInPercentage'] <- diffInPercentage
  repos_data[repos_data$fullName == fullName, 'abrupt_changes'] <- abrupt_increases + abrupt_decreases
  repos_data[repos_data$fullName == fullName, 'abrupt_increases'] <- abrupt_increases
  repos_data[repos_data$fullName == fullName, 'abrupt_decreases'] <- abrupt_decreases
  
}

repos_data$abruptChangesRatePerYear <- repos_data$abrupt_changes / repos_data$monthlyIntervals * 12
repos_data$abruptIncreaseRatePerYear <- repos_data$abrupt_increases / repos_data$monthlyIntervals * 12
repos_data$abruptDecreaseRatePerYear <- repos_data$abrupt_decreases / repos_data$monthlyIntervals * 12


###############################################################################
# STATISTICAL ANALYSIS: medianRunDuration in First Month of GHActions Adoption grouped by project category and LOC SIZE
###############################################################################

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(medianRunDurationInMinFirstMonth ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianRunDurationInMinFirstMonth ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianRunDurationInMinFirstMonth ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')
stat.test[stat.test$loc_size == 'small',]$y.position <- 25
stat.test[stat.test$loc_size == 'medium',]$y.position <- 33
stat.test[stat.test$loc_size == 'large',]$y.position <- 100


medianRunDurationInMinFirstMonthByProjectCategoryAndSize <-
  summarise(group_by(repos_data %>% filter(!is.na(medianRunDurationInMinFirstMonth)), loc_size, generalProjectCategory), 
            months = length(medianRunDurationInMinFirstMonth),
            min = min(medianRunDurationInMinFirstMonth, na.rm = TRUE),
            q1 = quantile(medianRunDurationInMinFirstMonth, probs = 0.25, na.rm = TRUE),
            median = median(medianRunDurationInMinFirstMonth, na.rm = TRUE),
            mean = mean(medianRunDurationInMinFirstMonth, na.rm = TRUE),
            q3 = quantile(medianRunDurationInMinFirstMonth, probs = 0.75, na.rm = TRUE),
            max = max(medianRunDurationInMinFirstMonth, na.rm = TRUE),
            boxplot_max_no_outlier = boxplot.stats(medianRunDurationInMinFirstMonth)$stats[5])


# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data %>% filter(!is.na(medianRunDurationInMinFirstMonth)), 
                 x = "loc_size", 
                 y = "medianRunDurationInMinFirstMonth", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Median Run Duration in First Month (minutes)",
                 outlier.shape = NA) +
  scale_y_continuous(breaks = seq(0, 120, 10), expand = c(0, 0)) +
  geom_text(data = medianRunDurationInMinFirstMonthByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'p = {p}\nδ = {cliffs_magnitude}',
                     tip.length = 0.000004)

ggpar(bxp, legend = "right", legend.title = "Category", ylim = c(0, 100))


###############################################################################
# STATISTICAL ANALYSIS: medianRunDuration in Last Month of GHActions Adoption grouped by project category and LOC SIZE
###############################################################################

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(medianRunDurationInMinLastMonth ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianRunDurationInMinLastMonth ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianRunDurationInMinLastMonth ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')
stat.test[stat.test$loc_size == 'small',]$y.position <- 20
stat.test[stat.test$loc_size == 'medium',]$y.position <- 60


medianRunDurationInMinLastMonthByProjectCategoryAndSize <-
  summarise(group_by(repos_data %>% filter(!is.na(medianRunDurationInMinLastMonth)), loc_size, generalProjectCategory), 
            months = length(medianRunDurationInMinLastMonth),
            min = min(medianRunDurationInMinLastMonth, na.rm = TRUE),
            q1 = quantile(medianRunDurationInMinLastMonth, probs = 0.25, na.rm = TRUE),
            median = median(medianRunDurationInMinLastMonth, na.rm = TRUE),
            mean = mean(medianRunDurationInMinLastMonth, na.rm = TRUE),
            q3 = quantile(medianRunDurationInMinLastMonth, probs = 0.75, na.rm = TRUE),
            boxplot_max_no_outlier = boxplot.stats(medianRunDurationInMinLastMonth)$stats[5],
            max = max(medianRunDurationInMinLastMonth, na.rm = TRUE))


# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data %>% filter(!is.na(medianRunDurationInMinLastMonth)), 
                 x = "loc_size", 
                 y = "medianRunDurationInMinLastMonth", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Median Run Duration in Last Month (minutes)",
                 outlier.shape = NA) +
  scale_y_continuous(breaks = seq(0, 120, 10), expand = c(0, 0)) +
  geom_text(data = medianRunDurationInMinLastMonthByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'p = {p}\nδ = {cliffs_magnitude}',
                     tip.length = 0.01)

ggpar(bxp, legend = "right", legend.title = "Category", ylim = c(0, 100))


###############################################################################
# STATISTICAL ANALYSIS: diffInPercentage in Last Month of GHActions Adoption grouped by project category and LOC SIZE
###############################################################################

repos_data$monthlyDiffInPercentageRate <- repos_data$diffInPercentage / repos_data$monthlyIntervals

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(monthlyDiffInPercentageRate ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(monthlyDiffInPercentageRate ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(monthlyDiffInPercentageRate ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')
stat.test[stat.test$loc_size == 'small',]$y.position <- 280
stat.test[stat.test$loc_size == 'medium',]$y.position <- 60


monthlyDiffInPercentageRateLastMonthByProjectCategoryAndSize <-
  summarise(group_by(repos_data %>% filter(!is.na(monthlyDiffInPercentageRate)), loc_size, generalProjectCategory), 
            months = length(monthlyDiffInPercentageRate),
            min = min(monthlyDiffInPercentageRate, na.rm = TRUE),
            q1 = quantile(monthlyDiffInPercentageRate, probs = 0.25, na.rm = TRUE),
            median = median(monthlyDiffInPercentageRate, na.rm = TRUE),
            mean = mean(monthlyDiffInPercentageRate, na.rm = TRUE),
            q3 = quantile(monthlyDiffInPercentageRate, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(monthlyDiffInPercentageRate)$stats[5],
            max = max(monthlyDiffInPercentageRate, na.rm = TRUE))

# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data %>% filter(!is.na(monthlyDiffInPercentageRate)), 
                 x = "loc_size", 
                 y = "monthlyDiffInPercentageRate", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "monthlyDiffInPercentageRate",
                 outlier.shape = NA) +
  # scale_y_continuous(breaks = seq(0, 120, 10), expand = c(0, 0)) +
  geom_text(data = monthlyDiffInPercentageRateLastMonthByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'p = {p}\nδ = {cliffs_magnitude}',
                     tip.length = 0.01)



ggpar(bxp, legend = "right", legend.title = "Category", ylim = c(min(monthlyDiffInPercentageRateLastMonthByProjectCategoryAndSize$min), 
                                                                 max(monthlyDiffInPercentageRateLastMonthByProjectCategoryAndSize$boxplot_max_without_outlier)))


###############################################################################
# STATISTICAL ANALYSIS: abruptChangesRatePerYear grouped by project category and LOC SIZE
###############################################################################

# repos_data$abruptChangesRatePerYear

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(abruptChangesRatePerYear ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(abruptChangesRatePerYear ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(abruptChangesRatePerYear ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')
stat.test[stat.test$loc_size == 'medium',]$y.position <- 5


abruptChangesRatePerYearLastMonthByProjectCategoryAndSize <-
  summarise(group_by(repos_data %>% filter(!is.na(abruptChangesRatePerYear)), loc_size, generalProjectCategory), 
            months = length(abruptChangesRatePerYear),
            min = min(abruptChangesRatePerYear, na.rm = TRUE),
            q1 = quantile(abruptChangesRatePerYear, probs = 0.25, na.rm = TRUE),
            median = median(abruptChangesRatePerYear, na.rm = TRUE),
            mean = mean(abruptChangesRatePerYear, na.rm = TRUE),
            q3 = quantile(abruptChangesRatePerYear, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(abruptChangesRatePerYear)$stats[5],
            max = max(abruptChangesRatePerYear, na.rm = TRUE))

# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data %>% filter(!is.na(abruptChangesRatePerYear)), 
                 x = "loc_size", 
                 y = "abruptChangesRatePerYear", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Abrupt Changes Rate Per Year",
                 outlier.shape = NA) +
  # scale_y_continuous(breaks = seq(0, 120, 10), expand = c(0, 0)) +
  geom_text(data = abruptChangesRatePerYearLastMonthByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'p = {p}\nδ = {cliffs_magnitude}',
                     tip.length = 0.04)

ggpar(bxp, legend = "right", legend.title = "Category", ylim = c(0, 6))


###############################################################################
# STATISTICAL ANALYSIS: abruptIncreaseRatePerYear grouped by project category and LOC SIZE
###############################################################################

repos_data$abruptIncreaseRatePerYear

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(abruptIncreaseRatePerYear ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(abruptIncreaseRatePerYear ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(abruptIncreaseRatePerYear ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')
stat.test[stat.test$loc_size == 'medium',]$y.position <- 3


abruptIncreaseRatePerYearLastMonthByProjectCategoryAndSize <-
  summarise(group_by(repos_data %>% filter(!is.na(abruptIncreaseRatePerYear)), loc_size, generalProjectCategory), 
            months = length(abruptIncreaseRatePerYear),
            min = min(abruptIncreaseRatePerYear, na.rm = TRUE),
            q1 = quantile(abruptIncreaseRatePerYear, probs = 0.25, na.rm = TRUE),
            median = median(abruptIncreaseRatePerYear, na.rm = TRUE),
            mean = mean(abruptIncreaseRatePerYear, na.rm = TRUE),
            q3 = quantile(abruptIncreaseRatePerYear, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(abruptIncreaseRatePerYear)$stats[5],
            max = max(abruptIncreaseRatePerYear, na.rm = TRUE))

# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data %>% filter(!is.na(abruptIncreaseRatePerYear)), 
                 x = "loc_size", 
                 y = "abruptIncreaseRatePerYear", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Abrupt Increase Rate Per Year",
                 outlier.shape = NA) +
  # scale_y_continuous(breaks = seq(0, 120, 10), expand = c(0, 0)) +
  geom_text(data = abruptIncreaseRatePerYearLastMonthByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'p = {p}\nδ = {cliffs_magnitude}',
                     tip.length = 0.04)


ggpar(bxp, legend = "right", legend.title = "Category", ylim = c(0, 4))


###############################################################################
# STATISTICAL ANALYSIS: abruptDecreaseRatePerYear grouped by project category and LOC SIZE
###############################################################################

# repos_data$abruptDecreaseRatePerYear

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(abruptDecreaseRatePerYear ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(abruptDecreaseRatePerYear ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(abruptDecreaseRatePerYear ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')
stat.test[stat.test$loc_size == 'medium',]$y.position <- 3


abruptDecreaseRatePerYearLastMonthByProjectCategoryAndSize <-
  summarise(group_by(repos_data %>% filter(!is.na(abruptDecreaseRatePerYear)), loc_size, generalProjectCategory), 
            months = length(abruptDecreaseRatePerYear),
            min = min(abruptDecreaseRatePerYear, na.rm = TRUE),
            q1 = quantile(abruptDecreaseRatePerYear, probs = 0.25, na.rm = TRUE),
            median = median(abruptDecreaseRatePerYear, na.rm = TRUE),
            mean = mean(abruptDecreaseRatePerYear, na.rm = TRUE),
            q3 = quantile(abruptDecreaseRatePerYear, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(abruptDecreaseRatePerYear)$stats[5],
            max = max(abruptDecreaseRatePerYear, na.rm = TRUE))

# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data %>% filter(!is.na(abruptDecreaseRatePerYear)), 
                 x = "loc_size", 
                 y = "abruptDecreaseRatePerYear", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Abrupt Decrease Rate Per Year",
                 outlier.shape = NA) +
  # scale_y_continuous(breaks = seq(0, 120, 10), expand = c(0, 0)) +
  geom_text(data = abruptDecreaseRatePerYearLastMonthByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'p = {p}\nδ = {cliffs_magnitude}',
                     tip.length = 0.04)


ggpar(bxp, legend = "right", legend.title = "Category", ylim = c(0, 4))



###


install.packages("dtw")
install.packages("proxy")
library(dtw)
library(proxy)

install.packages("dtwclust")
library(dtwclust)



time_series_df <- repos_month_date_intervals %>% filter(loc_size == 'large' & 
                                                          generalProjectCategory == 'ML' &
                                                          !is.na(medianRunDurationInMinutes)) %>% select(proj,
                                                                                                         intervalOrder, 
                                                                                                         medianRunDurationInMinutes)

time_series_df <- time_series_df[time_series_df$proj != 'opencv/dldt',]


time_series <- lapply(split(time_series_df$medianRunDurationInMinutes, time_series_df$proj), as.numeric)

distMatrix <- dist(time_series, method="DTW")

hc <- hclust(distMatrix, method="average")

plot(hc, main="")

clustering_result <- dtwclust(time_series, type = "hierarchical")

ggplot(time_series_df, aes(x=intervalOrder, y=medianRunDurationInMinutes, colour=proj)) + 
  geom_path() +
  theme(legend.position="none")


summary(time_series_df)

#---------------


repos_data$generalProjectCategory

sqldf('select COUNT(*)
      from repos_data
      where medianRunDurationInMinLastMonth < medianRunDurationInMinFirstMonth
      group by generalProjectCategory')



bxp <- ggboxplot(repos_data %>% filter(!is.na(repos_data$abruptChangesRatePerYear)), 
                 x = "loc_size", 
                 y = "abruptChangesRatePerYear", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Median Run Duration in First Month (minutes)",
                 outlier.shape = NA) +
  # scale_y_continuous(breaks = seq(0, 120, 10), expand = c(0, 0)) +
  geom_text(data = medianRunDurationInMinFirstMonthByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'p = {p}\nδ = {cliffs_magnitude}',
                     tip.length = 0.001)

ggpar(bxp, legend = "right", legend.title = "Category", ylim = c(0, 100))







##########################################################################
##########################################################################
##########################################################################

# backup backup backup backup backup backup backup backup backup backup

##########################################################################
##########################################################################
##########################################################################


###########################################################
# Calculating the commits rate per day by project
###########################################################

repos_data$commitsPerDay <- NA
for(proj in unique(repos_data$fullName)){
  proj_commits <- commits_data[commits_data$fullName == proj,]
  proj_commits_count <- nrow(proj_commits)
  
  first_commit_date <- min(proj_commits$commiterDate)
  last_commit_date <- max(proj_commits$commiterDate)
  active_commit_period <- as.numeric(difftime(last_commit_date, first_commit_date, units = "days")) + 1
  
  rate_commits_per_day <- proj_commits_count / active_commit_period
  repos_data[repos_data$fullName == proj, 'commitsPerDay'] <- rate_commits_per_day
}

###########################################################
# Ploting the histogram of commits for the large Non ML projects
###########################################################

large_no_ml_repos <- repos_data[repos_data$generalProjectCategory == 'No ML' & repos_data$loc_size == 'large',]
large_no_ml_repos$fullName

proj <- "p-org/P"
proj_commits <- commits_data[commits_data$fullName == proj,]
proj_commits_count <- nrow(proj_commits)
commitsPerDay <- repos_data[repos_data$fullName == proj,]$commitsPerDay
first_commit_date <- min(proj_commits$commiterDate)
last_commit_date <- max(proj_commits$commiterDate)
active_commit_period <- as.numeric(difftime(last_commit_date, first_commit_date, units = "days")) + 1
active_commit_period_years <- round(active_commit_period / 365, 1)

dates <- as.POSIXlt(proj_commits$commiterDate)

df <- data.frame(Data = dates)
df$MesAno <- format(df$Data, "%m-%Y") # Adicionar coluna com o mês-ano

# Plotar o histograma de frequência de datas por mês-ano com ggplot2
ggplot(df, aes(x = MesAno)) +
  geom_histogram(stat = "count", color = "black", fill = "lightblue") +
  labs(title = paste(proj, "- Datas por Mês-Ano"),
       subtitle = paste("Commits:",proj_commits_count,"- CommitPeriod:",active_commit_period_years,"anos - CommitsPerDay:", round(commitsPerDay, 2)),
       y = "Frequência",
       x = "")
# ggtitle("Histograma de Frequência de Datas por Mês-Ano") +
# xlab("Mês-Ano") +
# ylab("Frequência")

# hist(proj_commits$commiterDate, breaks = 1, main = "Histograma de Datas", xlab = "Datas", ylab = "Frequência")

sqldf("select fullName, commitsInDefaultBranchAfterGHAAdaptionPeriod as commits, lines_of_code as LOC, loc_size, forks, watchers
      from repos_data repos
      where loc_size = 'large' and generalProjectCategory = 'No ML'
      ORDER BY commits DESC")

###########################################################
# Calculating the commiters/contributors by project
###########################################################
repos_data$commiters_count <- NA
for(proj in unique(repos_data$fullName)){
  proj_commits <- commits_data[commits_data$fullName == proj,]
  proj_commiters <- unique(proj_commits$commiterEmail)
  proj_commiters <- proj_commiters[!proj_commiters == 'noreply@github.com']
  proj_commiters_count <- length(proj_commiters)
  repos_data[repos_data$fullName == proj, 'commiters_count'] <- proj_commiters_count
}

summarise(
  group_by(repos_data, loc_size, generalProjectCategory), 
  count = length(commiters_count),
  median = median(commiters_count),
  mean = mean(commiters_count))

# library("ggpubr")
# ggscatter(repos_data, x = "commitsPerDay", y = "commiters_count", 
#           add = "reg.line", conf.int = TRUE, 
#           cor.coef = TRUE, cor.method = "pearson",
#           xlab = "Commits per day", ylab = "Commiters")
# 
# 
cor(repos_data$commitsPerDay, repos_data$commiters_count)

#####################################################################
# Calculating the commits rate per day of week
#####################################################################

## This function calculate the number of occurrences of a weekday in a date interval
calculateWeekdayOcurrencesInInterval <- function(startDate, endDate, weekdayLabel){
  myDates <-seq(from = startDate, to = endDate, by = "days")
  return(length(which(wday(myDates, label = TRUE, abbr = FALSE)==weekdayLabel)))
}

## Weekdays labels
weekdays <- c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

weekdays_count_by_project <- data.frame()

## This loop calculates the occurrences of all weekdays in the project commit lifetime interval
## The result of this operation is stored in the weekdays_count_by_project dataframe
for(fullName in unique(commits_data$fullName)){
  
  proj_info <- commits_data[commits_data$fullName == fullName,]
  firstCommitDateIn <- min(proj_info$commiterDate)
  lastCommitDateIn <- max(proj_info$commiterDate)
  
  active_commit_period <- as.numeric(difftime(as.POSIXlt(lastCommitDateIn), 
                                              as.POSIXlt(firstCommitDateIn), 
                                              units = "days")) + 1
  for(weekDay in weekdays){
    
    weekdayOcurrences <- calculateWeekdayOcurrencesInInterval(
      as.POSIXlt(firstCommitDateIn), 
      as.POSIXlt(lastCommitDateIn),
      weekDay)
    temp <- data.frame(fullName, 
                       firstCommitDateIn,
                       lastCommitDateIn,
                       active_commit_period,
                       weekDay,
                       weekdayOcurrences)
    weekdays_count_by_project <- rbind(weekdays_count_by_project, temp)
  }
}

## getting the project weekday commits rate grouped by weekday
proj_commit_rate_by_weekday <- sqldf("select repo.fullName as fullName, 
                    repo.generalProjectCategory, loc_size, 
                    c.weekDay, weekDayNumber, count(*) as commits_count,
                    weekdayOcurrences, CAST(count(*) AS float)/weekdayOcurrences as weekdayCommitsRate
               from commits_data c
               inner join repos_data repo ON c.repo_id = repo.id
               inner join weekdays_count_by_project wd_count 
                  ON wd_count.fullName = repo.fullName AND
                     wd_count.weekDay = c.weekDay
               group by repo.fullName, loc_size, c.weekDay, weekDayNumber
               order by repo.fullName, weekDayNumber")

proj_commit_rate_by_weekday$weekDay <- factor(proj_commit_rate_by_weekday$weekDay, levels=weekdays)

##########################################################################
# Plotting commits count grouped by project category and weekday (Barplot)
##########################################################################

## getting the commits count grouped by project category and day of week
commits_count_by_category_and_weekday <- sqldf("select repo.generalProjectCategory, 
                                                       c.weekDay, count(*) as commits_count
                                               from commits_data c
                                               inner join repos_data repo ON c.repo_id = repo.id
                                               group by repo.generalProjectCategory, c.weekDay
                                               order by weekDayNumber")

commits_count_by_category_and_weekday$weekDay <- factor(commits_count_by_category_and_weekday$weekDay, levels=weekdays)

# Barplot of commits count grouped by project category and day of week
ggplot(commits_count_by_category_and_weekday, aes(weekDay, commits_count, fill = generalProjectCategory)) +
  geom_bar(stat="identity", position = "dodge") +
  labs(fill="Category") +
  xlab("Day of week") +
  ylab("# Commits")

##########################################################################
# Plotting commits rate grouped by project category and weekday (Barplot)
##########################################################################

## Getting median commits rate per day of week grouped by project category
commit_rate_by_category_and_weekday <- sqldf("select generalProjectCategory, weekDay,
                                                     sum(commits_count) commits_count,
                                                     avg(weekdayCommitsRate) weekdayCommitsRateMean,
                                                     median(weekdayCommitsRate) weekdayCommitsRateMedian
                                              from proj_commit_rate_by_weekday
                                              group by generalProjectCategory, weekDay
                                              order by generalProjectCategory, weekDayNumber")

commit_rate_by_category_and_weekday

## Barplot median commits rate per day of week grouped by project category
ggplot(commit_rate_by_category_and_weekday, aes(weekDay, weekdayCommitsRateMedian, fill = generalProjectCategory)) +
  geom_bar(stat="identity", position = "dodge") +
  geom_text(aes(label=round(weekdayCommitsRateMedian, digits = 2)), vjust=1.6, color="white",
            position = position_dodge(0.9), size=3.5)+
  # geom_text(aes(label=round(weekdayCommitsRateMedian, digits = 2)), vjust=1.6, color="white", size=4) +
  labs(fill="Category") +
  xlab("Day of week") +
  ylab("Commits rate per day (median)")

## Boxplot of commits rate per project category
medianData <- summarise(
  group_by(proj_commit_rate_by_weekday, weekDay, generalProjectCategory),
  median = median(weekdayCommitsRate))

ggplot(proj_commit_rate_by_weekday, aes(x=weekDay, y=weekdayCommitsRate, fill=generalProjectCategory)) +
  geom_boxplot(outlier.shape = NA) +
  coord_cartesian(ylim =  c(0, 5.5)) +
  geom_text(data = medianData, aes(weekDay, median, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3, vjust = -0.5) +
  labs(fill="Category") +
  ylab("Commits rate per day")
# + theme(axis.title.x=element_blank(),
#       legend.position = "none"
#       )

##########################################################################
# Plotting commits rate per day by project category (Barplot)
##########################################################################

## Getting commits rate per day grouped by project category
commitsRatePerDayByProjectCategoryStats <- summarise(
  group_by(repos_data, generalProjectCategory), 
  count = length(commitsPerDay),
  median = median(commitsPerDay),
  mean = mean(commitsPerDay))

## Getting commits rate per day grouped by project category and size
commitsRatePerDayByProjectCategoryAndSizeStats <- summarise(
  group_by(repos_data, loc_size, generalProjectCategory), 
  count = length(commitsPerDay),
  median = median(commitsPerDay),
  mean = mean(commitsPerDay))

## Barplot of commits rate per project category (median)
ggplot(commitsRatePerDayByProjectCategoryStats, aes(generalProjectCategory, median, fill = generalProjectCategory)) +
  geom_bar(stat="identity", position = "dodge") +
  geom_text(aes(label=round(median, digits = 2)), vjust=1.6, color="white", size=4) +
  labs(fill="Project Category") +
  xlab("Project Category") +
  ylab("Commits rate per day (median)")

## Boxplot of commits rate per project category

infrequent_commit_threshould = 1

ggplot(repos_data, aes(x=generalProjectCategory, y=commitsPerDay, fill=generalProjectCategory)) + 
  # geom_boxplot() +
  geom_boxplot(outlier.shape = NA) +
  coord_cartesian(ylim =  c(0, 3.5)) +
  geom_text(data = commitsRatePerDayByProjectCategoryStats, aes(generalProjectCategory, median, label = round(median, digits = 2)), 
            position = position_dodge(width = 0.8), size = 4, vjust = -0.5) + 
  labs(fill="Category") +
  ylab("Commits rate per day") + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) +
  geom_hline(yintercept = infrequent_commit_threshould, colour = 'red', show_guide = TRUE) +
  scale_color_manual(values = c("INFREQUENT COMMIT\nACTIVITY THRESHOLD" = "red"))

###############################################################################
# STATISTICAL ANALYSIS: commits rate per day grouped by project category and LOC SIZE
###############################################################################

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(commitsPerDay ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(commitsPerDay ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(commitsPerDay ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

commitsRatePerDayByProjectCategoryAndSize <-
  summarise(group_by(repos_data, loc_size, generalProjectCategory), 
            projects = length(commitsPerDay),
            median = median(commitsPerDay),
            mean = mean(commitsPerDay))

# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data, x = "loc_size", y = "commitsPerDay", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Commits per day") +
  # scale_y_continuous(expand = c(0, 2.0)) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'Effect Size = {cliffs_magnitude}') + 
  geom_text(data = commitsRatePerDayByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) + 
  geom_text(data = stat.test,
            aes(x = loc_size, y = y.position,
                label = ifelse(p < 0.05, paste("p-value =",as.character(p)), "")),
            vjust = -2.0, size = 4, color = "black")

ggpar(bxp,legend = "right", legend.title = "Category")


# boxplots commits rate per day grouped by project category and LOC size
ggplot(repos_data, aes(x=loc_size, y=commitsPerDay, fill=generalProjectCategory)) + 
  geom_boxplot() +
  geom_boxplot(outlier.shape = NA) +
  # coord_cartesian(ylim =  c(0, 5)) +
  geom_text(data = commitsRatePerDayByProjectCategoryAndSize, aes(loc_size, median, label = round(median, digits = 2)), 
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) + 
  labs(fill="Category") +
  xlab("LOC Size") +
  ylab("Commits per day") +
  geom_hline(yintercept = infrequent_commit_threshould, colour = 'red', show_guide = TRUE) +
  scale_color_manual(values = c("INFREQUENT COMMIT\nACTIVITY THRESHOLD" = "red"))


##########################################################################
# Defining infrequent commits threshould
##########################################################################

summary(repos_data$commitsPerDay)
infrequent_commit_threshould <- mean(repos_data$commitsPerDay)
infrequent_commit_threshould

summarise(group_by(repos_data, loc_size, generalProjectCategory), 
          count = length(commitsPerDay),
          median = median(commitsPerDay),
          mean = mean(commitsPerDay))

###############################################################################
# ANALYSIS: CALCULATING THE PERCENTAGE OF PROJECTS WITH COMMIT RATE LOWER THAN 1 
# GROUPED BY PROJECT CATEGORY
###############################################################################

## getting the total of projects per category (AI-ML or No AI-ML)
projects_per_category <- sqldf("select generalProjectCategory, count(*) total_projects
                              from repos_data repos
                              group by generalProjectCategory
                              ")

projects_per_category

infrequent_commit_threshould <- 1

## getting the total of projects per category with infrequent commits
projects_with_infrequent_commits_per_category <- sqldf(paste("select generalProjectCategory, count(*) projects_with_infrequent_commits
            from repos_data repos
            where repos.commitsPerDay <", infrequent_commit_threshould,
                                                             "group by generalProjectCategory", sep = " "))

# getting the total and percentage of projects per category with infrequent commits
percentage_of_projects_with_infrequent_commits_per_category <- sqldf("select proj_per_cat.generalProjectCategory, 
              proj_per_cat.total_projects, 
              proj_infr_commits_per_cat.projects_with_infrequent_commits, 
              (CAST(proj_infr_commits_per_cat.projects_with_infrequent_commits as FLOAT) / 
                  proj_per_cat.total_projects * 100) percent
      from projects_per_category proj_per_cat
      inner join projects_with_infrequent_commits_per_category proj_infr_commits_per_cat
      ON proj_per_cat.generalProjectCategory = proj_infr_commits_per_cat.generalProjectCategory")

percentage_of_projects_with_infrequent_commits_per_category

###############################################################################
# ANALYSIS: CALCULATING THE PERCENTAGE OF PROJECTS WITH COMMIT RATE LOWER THAN 1 
# GROUPED BY PROJECT CATEGORY AND SIZE
###############################################################################

## getting the total of projects per category (AI-ML or No AI-ML)
projects_per_category_and_size <- sqldf("select generalProjectCategory, loc_size, count(*) total_projects
                              from repos_data repos
                              group by generalProjectCategory, loc_size
                              ")

## getting the total of projects grouped by category and size with infrequent commits
projects_with_infrequent_commits_per_category_and_sloc <- sqldf(paste("select generalProjectCategory, loc_size, count(*) projects_with_infrequent_commits
            from repos_data repos
            where repos.commitsPerDay <", infrequent_commit_threshould,
                                                                      "group by generalProjectCategory, loc_size", sep = " "))


# getting the total and percentage of projects per category and size with infrequent commits
projects_with_infrequent_commits_per_category_and_sloc <- sqldf(
  "select proj_per_cat.generalProjectCategory, 
              proj_per_cat.loc_size,
              proj_per_cat.total_projects, 
              proj_infr_commits_per_cat.projects_with_infrequent_commits, 
              (CAST(proj_infr_commits_per_cat.projects_with_infrequent_commits as FLOAT) / 
                  proj_per_cat.total_projects * 100) percent
      from projects_per_category_and_size proj_per_cat,
           projects_with_infrequent_commits_per_category_and_sloc proj_infr_commits_per_cat
      where proj_per_cat.generalProjectCategory = proj_infr_commits_per_cat.generalProjectCategory and
            proj_per_cat.loc_size = proj_infr_commits_per_cat.loc_size
      order by proj_per_cat.loc_size")

projects_with_infrequent_commits_per_category_and_sloc
clipr::write_clip(projects_with_infrequent_commits_per_category_and_sloc)

##############################################################################
# Statistical Analysis - MWW test comparison between commits rate per day
# per project category and size
##############################################################################

loc_sizes = c("small", "medium", "large")

proc_result <- data.frame()

for(loc_size in loc_sizes){
  
  commits_per_day_by_AI_ML_projects <- repos_data[repos_data$generalProjectCategory == "ML" & 
                                                    repos_data$loc_size == loc_size,]$commitsPerDay
  
  commits_per_day_by_no_AI_ML_projects <- repos_data[repos_data$generalProjectCategory == "No ML" & 
                                                       repos_data$loc_size == loc_size,]$commitsPerDay
  
  shapiro_test_commits_per_day_AI_ML_projects <- shapiro.test(commits_per_day_by_AI_ML_projects)
  shapiro_test_commits_per_day_no_AI_ML_projects <- shapiro.test(commits_per_day_by_no_AI_ML_projects)
  
  wilcox_test_commits_per_day <- wilcox.test(commits_per_day_by_AI_ML_projects, commits_per_day_by_no_AI_ML_projects)
  cliff_delta_commits_per_day <- cliff.delta(commits_per_day_by_AI_ML_projects, commits_per_day_by_no_AI_ML_projects)
  
  temp_proc_result <- data.frame(loc_size, 
                                 length(commits_per_day_by_AI_ML_projects),
                                 length(commits_per_day_by_no_AI_ML_projects),
                                 median(commits_per_day_by_AI_ML_projects),
                                 median(commits_per_day_by_no_AI_ML_projects),
                                 mean(commits_per_day_by_AI_ML_projects),
                                 mean(commits_per_day_by_no_AI_ML_projects),
                                 wilcox_test_commits_per_day$p.value,
                                 cliff_delta_commits_per_day$magnitude,
                                 cliff_delta_commits_per_day$estimate,
                                 shapiro_test_commits_per_day_AI_ML_projects$p.value,
                                 shapiro_test_commits_per_day_no_AI_ML_projects$p.value
  )
  
  proc_result <- rbind(proc_result, temp_proc_result)                                 
}

colnames(proc_result) <- c("loc_size", 
                           "AI_ML_projects_count", 
                           "no_AI_ML_projects_count",
                           "median_AI_ML_projects", 
                           "median_no_AI_ML_projects", 
                           "mean_AI_ML_projects", 
                           "mean_no_AI_ML_projects", 
                           "wilcox_test_p_value", 
                           "cliff_delta_magnitude", 
                           "cliff_delta_estimate",
                           "shapiro_p_value_AI_ML_projects",
                           "shapiro_p_value_no_AI_ML_projects") 

proc_result

clipr::write_clip(proc_result)

##############################################################################
# Statistical Analysis - Time to Fix broken run
##############################################################################

###########################################################
## importing GHA run dataset
###########################################################

gha_runs_data <- read.csv2("../datasets/gha-runs-info_v8.csv", sep = ",", dec=".", na.strings = c('NULL'))
gha_runs_data <- gha_runs_data[gha_runs_data$fullName %in% unique(repos_data$fullName),]

## Adding the 'fullName' and 'generalProjectCategory' columns to the dataset
gha_runs_data <- left_join(gha_runs_data,
                           repos_data %>% dplyr::select(fullName, 
                                                        loc_size,
                                                        generalProjectCategory),
                           by = "fullName")


calculateTimeToFixBrokenRunStats <- function(runs){
  if(length(runs) != 0){
    summary_time_to_fix_failed_runs <- summary(runs$timeToFix)
    return(
      list(
        min = as.numeric(summary_time_to_fix_failed_runs[1]),
        first_quartile = as.numeric(summary_time_to_fix_failed_runs[2]),
        median = as.numeric(summary_time_to_fix_failed_runs[3]),
        mean = as.numeric(summary_time_to_fix_failed_runs[4]),
        third_quartile = as.numeric(summary_time_to_fix_failed_runs[5]),
        max = as.numeric(summary_time_to_fix_failed_runs[6])
      )
    )
  }
  return(NA)
}

## calculating the time to fix broken runs by repository
calculateTimeToFixBrokenRunByRepos <- function(workflowRuns){
  
  workflowRuns <- workflowRuns[order(workflowRuns$workflow_id, workflowRuns$updatedAt),]
  # workflowRuns <- workflowRuns[!is.na(workflowRuns$updatedAt),]
  
  workflowRuns$fixedBy <- NA
  workflowRuns$fixedAt <- NA
  workflowRuns$timeToFix <- NA
  
  if(nrow(workflowRuns) != 0){
    # order all runs of a project by its updatedAt attribute
    # workflowRuns <- workflowRuns[order(workflowRuns$updatedAt),]
    
    failed_run_date <- NA
    failed_run <- NA
    failed_run_index <- NA
    current_wokflow_id <- workflowRuns[1,]$workflow_id
    
    for(i in 1:nrow(workflowRuns)){
      run <- workflowRuns[i,]
      
      if(current_wokflow_id != run$workflow_id){
        failed_run_date <- NA
        failed_run <- NA
        failed_run_index <- NA
        current_wokflow_id <- run$workflow_id
      }
      
      if(is.na(failed_run_date) && run$conclusion %in% c("failure")){
        failed_run_date <- run$updatedAt
        failed_run_index <- i
        # print(paste("Failed Run date: ", failed_run_date))
      }
      if(!is.na(failed_run_date) && run$conclusion == "success"){
        passed_run_date <- run$updatedAt
        time_to_fix_run <- as.numeric(difftime(passed_run_date, failed_run_date, units = "hours")) / 24 # in days
        failed_run_date <- NA
        workflowRuns[failed_run_index,]$fixedBy <- run$ghId
        workflowRuns[failed_run_index,]$fixedAt <- run$updatedAt
        workflowRuns[failed_run_index,]$timeToFix <- time_to_fix_run
        
        # print(paste("Next passed Run date: ", passed_run_date))
        # print(paste("Time to fix run: ", time_to_fix_run))
        # print(time_to_fix_failed_runs)
      }
    }
    if(!is.na(failed_run_date)){
      # if a run failed and until the moment that we retrived the runs data for the project
      # there wasn't another run that succeed, we were getting the date of the last run of our dataset
      # as the date of that fixed the previous failed run.
      # It wasn't accurate. So we removed this step, and don't account for the time to fix of
      # that run
      # last_run <- workflowRuns[nrow(workflowRuns),]
      # time_to_fix_run <- as.numeric(difftime(last_run$updatedAt, failed_run_date, units = "hours")) / 24 
      # workflowRuns[failed_run_index,]$timeToFix <- time_to_fix_run
      # print(paste("Time to fix run: ", time_to_fix_run))
    }
  }
  return(workflowRuns)
}

## calculating the time to fix broken runs for all repositories
calculateTimeToFixBrokenRunAllRepos <- function(runs){
  runs_aux = data.frame()
  runs_colnames <- NA
  for(proj in unique(runs$fullName)){
    proj_runs <- runs[runs$fullName == proj,]
    proj_runs <- calculateTimeToFixBrokenRunByRepos(proj_runs)
    runs_aux <- rbind(runs_aux, proj_runs)
    runs_colnames <- names(runs_aux)
  }
  colnames(runs_aux) <- runs_colnames
  return(runs_aux)
}

## adding the time to fix broken run for each studied repository

# gha_runs_test <- calculateTimeToFixBrokenRunAllRepos(gha_runs_data[gha_runs_data$fullName == 'BLKSerene/Wordless',])

gha_runs_data <- calculateTimeToFixBrokenRunAllRepos(gha_runs_data)
gha_runs_data$timeToFixInHours <- gha_runs_data$timeToFix * 24

write.csv(gha_runs_data, file = "../datasets/gha-runs-info_with_time_to_fix_v8.csv", row.names = FALSE, sep = ",", dec = ".", na = c('NULL'))

## calculating statistics for time to fix broken run for each studied repository
repos_data$minTimeToFixBrokenRun <- NA
repos_data$firstQuartileTimeToFixBrokenRun <- NA
repos_data$medianTimeToFixBrokenRun <- NA
repos_data$meanTimeToFixBrokenRun <- NA
repos_data$thirdQuartileTimeToFixBrokenRun <- NA
repos_data$maxTimeToFixBrokenRun <- NA

for(proj in unique(gha_runs_data$fullName)){
  proj_runs <- gha_runs_data[gha_runs_data$fullName == proj,]
  timeToFixBrokenRun <- calculateTimeToFixBrokenRunStats(proj_runs)
  # print(paste(proj, " - mean time to fix run: ", calculateMeanTimeToFixBrokenRun(proj_runs))) 
  if(!is.null(timeToFixBrokenRun) && !is.na(timeToFixBrokenRun)){
    repos_data[repos_data$fullName == proj, 'minTimeToFixBrokenRun'] <- timeToFixBrokenRun$min
    repos_data[repos_data$fullName == proj, 'firstQuartileTimeToFixBrokenRun'] <- timeToFixBrokenRun$first_quartile  
    repos_data[repos_data$fullName == proj, 'medianTimeToFixBrokenRun'] <- timeToFixBrokenRun$median  
    repos_data[repos_data$fullName == proj, 'meanTimeToFixBrokenRun'] <- timeToFixBrokenRun$mean
    repos_data[repos_data$fullName == proj, 'thirdQuartileTimeToFixBrokenRun'] <- timeToFixBrokenRun$third_quartile  
    repos_data[repos_data$fullName == proj, 'maxTimeToFixBrokenRun'] <- timeToFixBrokenRun$max
  }
}

#############################################################################
# getting the total number of broken runs grouped by project category
sqldf("select generalProjectCategory, count(*) total_broken_runs
      from gha_runs_data b
      where b.timeToFixInHours IS NOT NULL
      group by generalProjectCategory
      ")

# getting the total number of broken runs grouped by project category and size
sqldf("select generalProjectCategory, loc_size as size, count(*) total_broken_runs
      from gha_runs_data b
      where b.timeToFixInHours IS NOT NULL
      group by generalProjectCategory, loc_size
      order by loc_size desc
      ")

# getting the total of projects with broken runs grouped by project category
sqldf("select generalProjectCategory, count(*) total_broken_runs
      from repos_data repo
      where medianTimeToFixBrokenRun IS NOT NULL
      group by generalProjectCategory
      ")

# getting the total of projects with broken runs grouped by project category and size
sqldf("select generalProjectCategory, loc_size, count(*) total_broken_runs
      from repos_data repo
      where medianTimeToFixBrokenRun IS NOT NULL
      group by generalProjectCategory, loc_size
      order by loc_size desc
      ")


## getting the third quartile of time to fix broken run distribution
## including runs for both project categories (i.e., AI-ML and No AI-ML projects)
summary(gha_runs_data$timeToFix)
summary(gha_runs_data$timeToFixInHours)

timeToFixBrokenRunThirdQuartileInHours <- 25.10
timeToFixBrokenRunThirdQuartileInDays <- 1.05

#####################################################################################
## verify how many projects has at least one run that took more than 0.47 to be fixed
#####################################################################################

runs_took_long_to_fix_ML_Tool <- gha_runs_data[gha_runs_data$generalProjectCategory == 'ML Tool' &
                                                 !is.na(gha_runs_data$timeToFix) & 
                                                 gha_runs_data$timeToFix > 0.47,]

runs_took_long_to_fix_applied_ML <- gha_runs_data[gha_runs_data$generalProjectCategory == 'Applied ML' &
                                                    !is.na(gha_runs_data$timeToFix) & 
                                                    gha_runs_data$timeToFix > 0.47,]

runs_took_long_to_fix_no_ML <- gha_runs_data[gha_runs_data$generalProjectCategory == 'No ML' &
                                               !is.na(gha_runs_data$timeToFix) & 
                                               gha_runs_data$timeToFix > 0.47,]


number_ML_Tool_projects <- nrow(repos_data[repos_data$generalProjectCategory == 'ML Tool',])
number_applied_ML_projects <- nrow(repos_data[repos_data$generalProjectCategory == 'Applied ML',])
number_no_ML_projects <- nrow(repos_data[repos_data$generalProjectCategory == 'No ML',])

number_ML_Tool_projects_with_long_time_to_fix <- length(unique(runs_took_long_to_fix_ML_Tool$fullName))
number_applied_ML_projects_with_long_time_to_fix <- length(unique(runs_took_long_to_fix_applied_ML$fullName))
number_no_ML_projects_with_long_time_to_fix <- length(unique(runs_took_long_to_fix_no_ML$fullName))

# percentage of ML Tool projects with at least one run that took long to be fixed
number_ML_Tool_projects_with_long_time_to_fix / number_ML_Tool_projects * 100

# percentage of Applied ML projects with at least one run that took long to be fixed
number_applied_ML_projects_with_long_time_to_fix / number_applied_ML_projects * 100

# percentage of No ML projects with at least one run that took long to be fixed
number_no_ML_projects_with_long_time_to_fix / number_no_ML_projects * 100



threshouldTimeToFixBrokenrunPerProjectCategoryAndSize <-
  summarise(group_by(repos_data[!is.na(repos_data$medianTimeToFixBrokenRunInHours), ], loc_size, generalProjectCategory), 
            projects = length(medianTimeToFixBrokenRunInHours),
            min = min(medianTimeToFixBrokenRunInHours),
            q1 = quantile(medianTimeToFixBrokenRunInHours, probs = 0.25),
            median = median(medianTimeToFixBrokenRunInHours),
            q3 = quantile(medianTimeToFixBrokenRunInHours, probs = 0.75),
            mean = mean(medianTimeToFixBrokenRunInHours))

#####################################################################################
## verify how many projects has their median time to fix broken runs higher than the defined threshould
#####################################################################################

# getting the median timeToFixBrokenRun grouped by category and project size
projects_per_category_and_size_count <- sqldf("SELECT r.generalProjectCategory, r.loc_size, 
              COUNT(*) projects_count, 
              MEDIAN(r.medianTimeToFixBrokenRun) medianTimeToFixBrokenRunInDays,
              MEDIAN(r.medianTimeToFixBrokenRun) * 24 medianTimeToFixBrokenRunInHours
       FROM repos_data r
       WHERE r.medianTimeToFixBrokenRun IS NOT NULL
       GROUP BY r.generalProjectCategory, r.loc_size
       ORDER BY r.loc_size desc")
projects_per_category_and_size_count

dim(gha_runs_data)
dim(commits_data)

## analyzing how many projects have broken runs that took more that 11.37 hours to be fixed
projects_with_runs_took_long_to_be_fixed <- sqldf(
  "SELECT r.generalProjectCategory, r.loc_size, 
                          COUNT(*) projects_with_long_broken_runs 
                  FROM repos_data r, threshouldTimeToFixBrokenrunPerProjectCategoryAndSize threshould
                  WHERE threshould.loc_size = r.loc_size AND 
                        threshould.generalProjectCategory = r.generalProjectCategory AND
                        r.medianTimeToFixBrokenRun IS NOT NULL and
                        r.medianTimeToFixBrokenRun > threshould.q3
                  GROUP BY r.generalProjectCategory, r.loc_size 
                  ORDER BY r.loc_size desc")
projects_with_runs_took_long_to_be_fixed

projects_with_runs_took_long_to_be_fixed <- left_join(projects_with_runs_took_long_to_be_fixed,
                                                      projects_per_category_and_size_count,
                                                      by = c("generalProjectCategory", "loc_size"))

projects_with_runs_took_long_to_be_fixed$percent <- 
  projects_with_runs_took_long_to_be_fixed$projects_with_long_broken_runs /
  projects_with_runs_took_long_to_be_fixed$projects_count * 100

View(projects_with_runs_took_long_to_be_fixed)


# ## MWW test comparing the median time to fix broken runs of AI-ML and No AI-ML projects
# wilcox.test(repos_data[repos_data$generalProjectCategory == 'AI-ML',]$medianTimeToFixBrokenRun,
#             repos_data[repos_data$generalProjectCategory == 'No AI-ML',]$medianTimeToFixBrokenRun)
# 
# ##Cliffs delta of the median time to fix broken runs of AI-ML and No AI-ML projects
# cliff.delta(repos_data[repos_data$generalProjectCategory == 'AI-ML',]$medianTimeToFixBrokenRun,
#             repos_data[repos_data$generalProjectCategory == 'No AI-ML',]$medianTimeToFixBrokenRun)


#####################################################################################
## plotting the time to fix broken runs grouped by project category and size
#####################################################################################

## converting timeToFixBrokenRun variable in days for hours
repos_data$medianTimeToFixBrokenRunInHours <- repos_data$medianTimeToFixBrokenRun * 24

## getting the stats for time to fix broken runs grouped by project category and size
timeToFixByProjectCategoryAndSize <-
  summarise(group_by(repos_data[!is.na(repos_data$medianTimeToFixBrokenRunInHours),], 
                     loc_size, generalProjectCategory), 
            count = length(medianTimeToFixBrokenRunInHours),
            median = median(medianTimeToFixBrokenRunInHours),
            mean = mean(medianTimeToFixBrokenRunInHours))

## plotting the time to fix broken runs grouped by project category and size
ggplot(repos_data, aes(x=loc_size, y=medianTimeToFixBrokenRunInHours, fill=generalProjectCategory)) + 
  geom_boxplot() +
  # geom_boxplot(outlier.shape = NA) +
  coord_cartesian(ylim =  c(0, 600)) +
  geom_text(data = timeToFixByProjectCategoryAndSize, aes(loc_size, median, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 4, vjust = -0.5) +
  labs(fill="Category") +
  xlab("LOC Size") +
  ylab("Median time to fix broken runs (hours)") +
  geom_hline(yintercept = 11.37, colour = 'red', show_guide = TRUE) +
  scale_color_manual(values = c("LONG TIME TO FIX BROKEN\nBUILDS THRESHOLD" = "red"))


###############################################################################
# STATISTICAL ANALYSIS: time to fix broken run per day grouped by project category and LOC SIZE
###############################################################################

# Define the order of the boxes
loc_size_box_order <- c("small", "medium", "large")

# Reorder the factor levels
repos_data$loc_size <- reorder(repos_data$loc_size, as.numeric(factor(repos_data$loc_size, levels = loc_size_box_order)))

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(medianTimeToFixBrokenRunInHours ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianTimeToFixBrokenRunInHours ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianTimeToFixBrokenRunInHours ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

medianTimeToFixBrokenRunByProjectCategoryAndSize <-
  summarise(group_by(repos_data[!is.na(repos_data$medianTimeToFixBrokenRunInHours),], loc_size, generalProjectCategory), 
            projects = length(medianTimeToFixBrokenRunInHours),
            median = median(medianTimeToFixBrokenRunInHours),
            mean = mean(medianTimeToFixBrokenRunInHours))

# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data, x = "loc_size", y = "medianTimeToFixBrokenRunInHours", 
                 outlier.shape = TRUE,
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "median time to fix broken run (hours)") +
  # scale_y_continuous(expand = c(0, 2.0)) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'Effect Size = {cliffs_magnitude}') + 
  geom_text(data = medianTimeToFixBrokenRunByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) + 
  geom_text(data = stat.test,
            aes(x = loc_size, y = y.position,
                label = ifelse(p < 0.05, paste("p-value =",as.character(p)), "")),
            vjust = -2.0, size = 4, color = "black")

ggpar(bxp,legend = "right", legend.title = "Category", ylim = c(0, 200))

#####################################################################################################
## statistical analyis of the median time to fix broken runs, comparing ML and No ML projects
#####################################################################################################

loc_sizes = c("small", "medium", "large")

proc_result <- data.frame()

for(loc_size in loc_sizes){
  
  time_to_fix_per_AI_ML_projects <- repos_data[repos_data$generalProjectCategory == "ML" & 
                                                 !is.na(repos_data$medianTimeToFixBrokenRunInHours) &
                                                 repos_data$loc_size == loc_size,]$medianTimeToFixBrokenRunInHours
  
  time_to_fix_per_no_AI_ML_projects <- repos_data[repos_data$generalProjectCategory == "No ML" & 
                                                    !is.na(repos_data$medianTimeToFixBrokenRunInHours) &
                                                    repos_data$loc_size == loc_size,]$medianTimeToFixBrokenRunInHours
  
  shapiro_test_time_to_fix_AI_ML_projects <- NULL
  shapiro_test_time_to_fix_no_AI_ML_projects <- NULL
  try(
    shapiro_test_time_to_fix_AI_ML_projects <- shapiro.test(time_to_fix_per_AI_ML_projects),
    silent = TRUE)
  try(
    shapiro_test_time_to_fix_no_AI_ML_projects <- shapiro.test(time_to_fix_per_no_AI_ML_projects),
    silent = TRUE)
  
  wilcox_test_time_to_fix_per_day <- wilcox.test(time_to_fix_per_AI_ML_projects, time_to_fix_per_no_AI_ML_projects)
  cliff_delta_time_to_fix_per_day <- cliff.delta(time_to_fix_per_AI_ML_projects, time_to_fix_per_no_AI_ML_projects)
  
  temp_proc_result <- data.frame(loc_size, 
                                 length(time_to_fix_per_AI_ML_projects),
                                 length(time_to_fix_per_no_AI_ML_projects),
                                 median(time_to_fix_per_AI_ML_projects),
                                 median(time_to_fix_per_no_AI_ML_projects),
                                 mean(time_to_fix_per_AI_ML_projects),
                                 mean(time_to_fix_per_no_AI_ML_projects),
                                 wilcox_test_time_to_fix_per_day$p.value,
                                 cliff_delta_time_to_fix_per_day$magnitude,
                                 cliff_delta_time_to_fix_per_day$estimate,
                                 if(is.null(shapiro_test_time_to_fix_AI_ML_projects)) NA else shapiro_test_time_to_fix_AI_ML_projects$p.value,
                                 if(is.null(shapiro_test_time_to_fix_no_AI_ML_projects)) NA else shapiro_test_time_to_fix_no_AI_ML_projects$p.value
  )
  
  proc_result <- rbind(proc_result, temp_proc_result)                                 
}

colnames(proc_result) <- c("loc_size", 
                           "AI_ML_projects_count", 
                           "no_AI_ML_projects_count", 
                           "median_AI_ML_projects", 
                           "median_no_AI_ML_projects",
                           "mean_AI_ML_projects", 
                           "mean_no_AI_ML_projects", 
                           "wilcox_test_p_value", 
                           "cliff_delta_magnitude", 
                           "cliff_delta_estimate",
                           "shapiro_p_value_AI_ML_projects",
                           "shapiro_p_value_no_AI_ML_projects"
) 

proc_result
View(proc_result)



##############################################################################
# Statistical Analysis - Run duration
##############################################################################

###########################################################
# importing GHA runs dataset
###########################################################

workflow_runs <- read.csv2("../datasets/gha-runs-info_v6.csv", sep = ",", dec=".", na.strings = c('NULL'))
workflow_runs <- workflow_runs[workflow_runs$fullName %in% unique(repos_data$fullName),]
workflow_runs$durationInMinutes <- workflow_runs$duration / 60

## Adding the 'fullName' and 'generalProjectCategory' columns to the dataset
workflow_runs <- left_join(workflow_runs,
                           repos_data %>% dplyr::select(fullName, 
                                                        loc_size,
                                                        generalProjectCategory),
                           by = "fullName")

dim(workflow_runs)
dim(workflow_runs[!is.na(workflow_runs$duration),])


temp_workflow_runs <- workflow_runs
temp_workflow_runs <- temp_workflow_runs[!is.na(temp_workflow_runs$duration),]
temp_workflow_runs <- temp_workflow_runs[temp_workflow_runs$duration >= 0,]

repos_data$meanRunDuration <- NA
repos_data$medianRunDuration <- NA
repos_data$meanRunDurationInMinutes <- NA
repos_data$medianRunDurationInMinutes <- NA
for(proj in unique(temp_workflow_runs$fullName)){
  proj_runs <- temp_workflow_runs[temp_workflow_runs$fullName == proj,]
  mean_run_duration <- mean(proj_runs$duration)
  median_run_duration <- median(proj_runs$duration)
  repos_data[repos_data$fullName == proj, 'meanRunDuration'] <- mean_run_duration
  repos_data[repos_data$fullName == proj, 'medianRunDuration'] <- median_run_duration
  repos_data[repos_data$fullName == proj, 'meanRunDurationInMinutes'] <- mean_run_duration / 60
  repos_data[repos_data$fullName == proj, 'medianRunDurationInMinutes'] <- median_run_duration / 60
}

View(repos_data)

## getting the number of projects and descriptive statistics of the 
## median run duration per project category
summarise(group_by(temp_workflow_runs, generalProjectCategory), 
          count = length(durationInMinutes),
          min = min(durationInMinutes),
          firstQuantile = quantile(durationInMinutes, 0.25),
          median = median(durationInMinutes),
          mean = mean(durationInMinutes),
          thirdQuantile = quantile(durationInMinutes, 0.75),
          max = max(durationInMinutes))

## getting the number of projects and descriptive statistics of the 
## median run duration per project category and size
summarise(group_by(repos_data, loc_size, generalProjectCategory), 
          count = length(medianRunDurationInMinutes),
          min = min(medianRunDurationInMinutes),
          firstQuantile = quantile(medianRunDurationInMinutes, 0.25),
          median = median(medianRunDurationInMinutes),
          mean = mean(medianRunDurationInMinutes),
          thirdQuantile = quantile(medianRunDurationInMinutes, 0.75),
          max = max(medianRunDurationInMinutes))


#####################################################################################################
## statistical analyis of the median run duration, comparing AI-ML and No AI-ML projects
#####################################################################################################

loc_sizes = c("small", "medium", "large")

proc_result <- data.frame()

for(loc_size in loc_sizes){
  
  run_duration_per_AI_ML_projects <- repos_data[repos_data$generalProjectCategory == "ML" & 
                                                  !is.na(repos_data$medianRunDurationInMinutes) &
                                                  repos_data$loc_size == loc_size,]$medianRunDurationInMinutes
  
  run_duration_per_no_AI_ML_projects <- repos_data[repos_data$generalProjectCategory == "No ML" & 
                                                     !is.na(repos_data$medianRunDurationInMinutes) &
                                                     repos_data$loc_size == loc_size,]$medianRunDurationInMinutes
  
  shapiro_test_run_duration_AI_ML_projects <- NULL
  shapiro_test_run_duration_no_AI_ML_projects <- NULL
  try(
    shapiro_test_run_duration_AI_ML_projects <- shapiro.test(run_duration_per_AI_ML_projects),
    silent = TRUE)
  try(
    shapiro_test_run_duration_no_AI_ML_projects <- shapiro.test(run_duration_per_no_AI_ML_projects),
    silent = TRUE)
  
  wilcox_test_run_duration_per_day <- wilcox.test(run_duration_per_AI_ML_projects, run_duration_per_no_AI_ML_projects)
  cliff_delta_run_duration_per_day <- cliff.delta(run_duration_per_AI_ML_projects, run_duration_per_no_AI_ML_projects)
  
  temp_proc_result <- data.frame(loc_size, 
                                 length(run_duration_per_AI_ML_projects),
                                 length(run_duration_per_no_AI_ML_projects),
                                 median(run_duration_per_AI_ML_projects),
                                 median(run_duration_per_no_AI_ML_projects),
                                 mean(run_duration_per_AI_ML_projects),
                                 mean(run_duration_per_no_AI_ML_projects),
                                 wilcox_test_run_duration_per_day$p.value,
                                 cliff_delta_run_duration_per_day$magnitude,
                                 cliff_delta_run_duration_per_day$estimate,
                                 if(is.null(shapiro_test_run_duration_AI_ML_projects)) NA else shapiro_test_run_duration_AI_ML_projects$p.value,
                                 if(is.null(shapiro_test_run_duration_no_AI_ML_projects)) NA else shapiro_test_run_duration_no_AI_ML_projects$p.value
  )
  
  proc_result <- rbind(proc_result, temp_proc_result)                                 
}

colnames(proc_result) <- c("size", 
                           "ML_projects", 
                           "no_ML_projects", 
                           "median_ML_run_dur", 
                           "median_no_ML_run_dur",
                           "mean_ML_run_dur", 
                           "mean_no_ML_run_dur", 
                           "wilcox_p_value", 
                           "cliff_delta_magnitude", 
                           "cliff_delta_estimate",
                           "shapiro_p_value_ML_run_duration",
                           "shapiro_p_value_no_ML_run_durations"
) 

proc_result
View(proc_result)

###############################################################################
# STATISTICAL ANALYSIS: run duration grouped by project category and LOC SIZE
###############################################################################

stat.test <- repos_data %>%
  group_by(loc_size) %>%
  wilcox_test(medianRunDurationInMinutes ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianRunDurationInMinutes ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianRunDurationInMinutes ~ generalProjectCategory)$magnitude)
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

medianRunDurationInMinutesByProjectCategoryAndSize <-
  summarise(group_by(repos_data, loc_size, generalProjectCategory), 
            projects = length(medianRunDurationInMinutes),
            median = median(medianRunDurationInMinutes),
            mean = mean(medianRunDurationInMinutes))

# Visualization: box plots with p-values
bxp <- ggboxplot(repos_data, x = "loc_size", y = "medianRunDurationInMinutes", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "median run duration (minutes)") +
  # scale_y_continuous(expand = c(0, 40)) +
  stat_pvalue_manual(stat.test, hide.ns = TRUE, label = 'Effect Size ({cliffs_magnitude})', vjust = -0.5) + 
  geom_text(data = medianRunDurationInMinutesByProjectCategoryAndSize, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) + 
  geom_text(data = stat.test,
            aes(x = loc_size, y = y.position,
                label = ifelse(p < 0.05, paste("p-value =",as.character(p)), "")),
            vjust = -2.5, size = 4, color = "black")

ggpar(bxp,legend = "right", legend.title = "Category")

#####################################################################################################
## statistical analyis of the median run duration, comparing projects by their LOC Size
#####################################################################################################

loc_sizes = c("small", "medium", "large")

generalProjectCategories <- c("ML", "No ML")

proc_result <- data.frame()

for(generalProjectCategory in generalProjectCategories){
  
  for(i in 1:(length(loc_sizes) - 1)){
    loc_size <- loc_sizes[i]
    
    run_duration_per_loc_size <- repos_data[repos_data$generalProjectCategory == generalProjectCategory & 
                                              !is.na(repos_data$medianRunDurationInMinutes) &
                                              repos_data$loc_size == loc_size,]$medianRunDurationInMinutes
    
    for(j in (i+1):length(loc_sizes)){
      
      loc_size_comp <- loc_sizes[j]
      
      run_duration_per_loc_size_comp <- repos_data[repos_data$generalProjectCategory == generalProjectCategory & 
                                                     !is.na(repos_data$medianRunDurationInMinutes) &
                                                     repos_data$loc_size == loc_size_comp,]$medianRunDurationInMinutes
      
      shapiro_test_run_duration <- NULL
      shapiro_test_run_duration_comp <- NULL
      try(
        shapiro_test_run_duration <- shapiro.test(run_duration_per_loc_size),
        silent = TRUE)
      try(
        shapiro_test_run_duration_comp <- shapiro.test(run_duration_per_loc_size_comp),
        silent = TRUE)
      
      wilcox_test_run_duration <- wilcox.test(run_duration_per_loc_size, run_duration_per_loc_size_comp)
      cliff_delta_run_duration <- cliff.delta(run_duration_per_loc_size, run_duration_per_loc_size_comp)
      
      temp_proc_result <- data.frame(generalProjectCategory,
                                     loc_size, 
                                     loc_size_comp,
                                     length(run_duration_per_loc_size),
                                     length(run_duration_per_loc_size_comp),
                                     median(run_duration_per_loc_size),
                                     median(run_duration_per_loc_size_comp),
                                     mean(run_duration_per_loc_size),
                                     mean(run_duration_per_loc_size_comp),
                                     wilcox_test_run_duration$p.value,
                                     cliff_delta_run_duration$magnitude,
                                     cliff_delta_run_duration$estimate,
                                     if(is.null(shapiro_test_run_duration)) NA else shapiro_test_run_duration$p.value,
                                     if(is.null(shapiro_test_run_duration_comp)) NA else shapiro_test_run_duration_comp$p.value
      )
      
      proc_result <- rbind(proc_result, temp_proc_result)                                 
    }
  }
}

colnames(proc_result) <- c("generalProjectCategory",
                           "group1", 
                           "group2",
                           "n1", 
                           "n2", 
                           "median_run_duration_group1", 
                           "median_run_duration_group2",
                           "mean_run_duration_group1", 
                           "mean_run_duration_group2", 
                           "wilcox_p_value", 
                           "cliff_delta_magnitude", 
                           "cliff_delta_estimate",
                           "shapiro_p_value_group1",
                           "shapiro_p_value_group2")

proc_result
View(proc_result)

#####################################################################################
## verifying how many projects has their median run duration higher than 10 minutes
## per project Category
#####################################################################################

# getting the median timeToFixBrokenRun grouped by category
projects_per_category_count <- sqldf(
  "SELECT r.generalProjectCategory, COUNT(*) projects_count
       FROM repos_data r
       GROUP BY r.generalProjectCategory")
projects_per_category_count

## analyzing how many projects have median run duration higher than 10 minutes
projects_with_long_run_duration <- sqldf(
  "SELECT generalProjectCategory, COUNT(*) projects_with_long_run_duration
                  FROM repos_data 
                  WHERE medianRunDurationInMinutes IS NOT NULL and
                        medianRunDurationInMinutes > 10
                  GROUP BY generalProjectCategory")
projects_with_long_run_duration

projects_with_long_run_duration <- left_join(projects_with_long_run_duration,
                                             projects_per_category_count,
                                             by = c("generalProjectCategory"))

projects_with_long_run_duration$percent <- 
  projects_with_long_run_duration$projects_with_long_run_duration /
  projects_with_long_run_duration$projects_count * 100

projects_with_long_run_duration
View(projects_with_long_run_duration)


#####################################################################################
## verifying how many projects has their median run duration higher than 10 minutes 
## per project category and loc size
#####################################################################################

# getting the median timeToFixBrokenRun grouped by category and project size
projects_per_category_and_size_count <- sqldf("SELECT r.generalProjectCategory, r.loc_size, 
              COUNT(*) projects_count
       FROM repos_data r
       GROUP BY r.generalProjectCategory, r.loc_size
       ORDER BY r.loc_size")
projects_per_category_and_size_count

## analyzing how many projects have median run duration higher than 10 minutes
projects_with_long_run_duration <- sqldf(
  "SELECT generalProjectCategory, loc_size, 
                          COUNT(*) projects_with_long_run_duration
                  FROM repos_data 
                  WHERE medianRunDurationInMinutes IS NOT NULL and
                        medianRunDurationInMinutes > 10
                  GROUP BY generalProjectCategory, loc_size 
                  ORDER BY loc_size")
projects_with_long_run_duration

projects_with_long_run_duration <- left_join(projects_with_long_run_duration,
                                             projects_per_category_and_size_count,
                                             by = c("generalProjectCategory", "loc_size"))

projects_with_long_run_duration$percent <- 
  projects_with_long_run_duration$projects_with_long_run_duration /
  projects_with_long_run_duration$projects_count * 100

projects_with_long_run_duration
View(projects_with_long_run_duration)


##############################################################################
# Statistical Analysis - Code Coverage
##############################################################################

###########################################################
## importing coverage dataset
###########################################################

coverage_data <- read.csv2("../datasets/coverage-info_v5.csv", sep = ",", dec=".", na.strings = c('NULL'))
coverage_data <- coverage_data[coverage_data$fullName %in% unique(repos_data$fullName),]

## the project RandolphVI/Next-Basket-Recommendation has 15 coveralls builds, 
## from which 9 builds have coverage attribute as NA and 6 have the coverage as 0
## then we exclude this project from our analysis
# coverage_data <- coverage_data[coverage_data$repo_name != 'RandolphVI/Next-Basket-Recommendation',]

unique(coverage_data$fullName)

## Adding the 'fullName' and 'generalProjectCategory' columns to the dataset
coverage_data <- left_join(coverage_data,
                           repos_data %>% dplyr::select(fullName, 
                                                        loc_size,
                                                        generalProjectCategory),
                           by = "fullName")

###########################################################
## processing coverage data for repositories
###########################################################

repos_data$coverage <- NA
for(proj in unique(coverage_data$fullName)){
  
  proj_data <- repos_data[repos_data$fullName == proj,]
  lastWorkflowRunAt <- as.Date(proj_data$lastWorkflowRunAt)
  grace_period_interval <- lastWorkflowRunAt - ddays(7)
  
  builds <- coverage_data[coverage_data$fullName == proj 
                          # & coverage_data$created_at >= grace_period_interval
                          # & as.Date(coverage_data$created_at) <= lastWorkflowRunAt
                          ,]
  
  if(nrow(builds) > 0){
    last_build_in_the_interval <- builds[order(builds$created_at),][nrow(builds),] 
    repos_data[repos_data$fullName == proj, 'coverage'] <- last_build_in_the_interval$covered_percent
  }
}

# getting the median and mean coverage grouped by category
sqldf("SELECT r.generalProjectCategory, COUNT(*) projects_count, 
            MEDIAN(r.coverage) median_coverage,
            AVG(r.coverage) mean_coverage
       FROM repos_data r
       WHERE r.coverage IS NOT NULL
       GROUP BY r.generalProjectCategory")


# getting the median and mean coverage grouped by category and project size
sqldf("SELECT r.generalProjectCategory, r.loc_size, COUNT(*) projects_count, 
        MEDIAN(r.coverage) median_coverage,
        AVG(r.coverage) mean_coverage
       FROM repos_data r
       WHERE r.coverage IS NOT NULL
       GROUP BY r.generalProjectCategory, r.loc_size
       ORDER BY r.loc_size")


columns <- c("id",
             "ghId",
             "projectCategory",
             "fullName",
             "loc_size",
             "language",
             "coverage")
View(repos_data[!is.na(repos_data$coverage), columns])



loc_sizes = c("small", "medium", "larger")

proc_result <- data.frame()

for(loc_size in loc_sizes){
  
  coverage_per_AI_ML_projects <- repos_data[repos_data$generalProjectCategory == "ML" & 
                                              !is.na(repos_data$coverage) &
                                              repos_data$loc_size == loc_size,]$coverage
  
  coverage_per_no_AI_ML_projects <- repos_data[repos_data$generalProjectCategory == "No ML" & 
                                                 !is.na(repos_data$coverage) &
                                                 repos_data$loc_size == loc_size,]$coverage
  
  shapiro_test_coverage_AI_ML_projects <- NULL
  shapiro_test_coverage_no_AI_ML_projects <- NULL
  try(
    shapiro_test_coverage_AI_ML_projects <- shapiro.test(coverage_per_AI_ML_projects),
    silent = TRUE)
  try(
    shapiro_test_coverage_no_AI_ML_projects <- shapiro.test(coverage_per_no_AI_ML_projects),
    silent = TRUE)
  
  wilcox_test_coverage_per_day <- wilcox.test(coverage_per_AI_ML_projects, coverage_per_no_AI_ML_projects)
  cliff_delta_coverage_per_day <- cliff.delta(coverage_per_AI_ML_projects, coverage_per_no_AI_ML_projects)
  
  temp_proc_result <- data.frame(loc_size, 
                                 length(coverage_per_AI_ML_projects),
                                 length(coverage_per_no_AI_ML_projects),
                                 median(coverage_per_AI_ML_projects),
                                 median(coverage_per_no_AI_ML_projects),
                                 mean(coverage_per_AI_ML_projects),
                                 mean(coverage_per_no_AI_ML_projects),
                                 wilcox_test_coverage_per_day$p.value,
                                 cliff_delta_coverage_per_day$magnitude,
                                 cliff_delta_coverage_per_day$estimate,
                                 if(is.null(shapiro_test_coverage_AI_ML_projects)) NA else shapiro_test_coverage_AI_ML_projects$p.value,
                                 if(is.null(shapiro_test_coverage_no_AI_ML_projects)) NA else shapiro_test_coverage_no_AI_ML_projects$p.value
  )
  
  proc_result <- rbind(proc_result, temp_proc_result)                                 
}

colnames(proc_result) <- c("loc_size", 
                           "AI_ML_projects_count", 
                           "no_AI_ML_projects_count", 
                           "median_AI_ML_projects", 
                           "median_no_AI_ML_projects",
                           "mean_AI_ML_projects", 
                           "mean_no_AI_ML_projects", 
                           "wilcox_test_p_value", 
                           "cliff_delta_magnitude", 
                           "cliff_delta_estimate",
                           "shapiro_p_value_AI_ML_projects",
                           "shapiro_p_value_no_AI_ML_projects"
) 

proc_result
View(proc_result)

summary(repos_data[repos_data$generalProjectCategory == 'AI-ML',]$coverage)
summary(repos_data[repos_data$generalProjectCategory == 'No AI-ML',]$coverage)

boxplot(repos_data[repos_data$generalProjectCategory == 'AI-ML',]$coverage,
        repos_data[repos_data$generalProjectCategory == 'No AI-ML',]$coverage)


View(repos_data[repos_data$generalProjectCategory == 'AI-ML' &
                  !is.na(repos_data$coverage) &
                  repos_data$coverage > 50,])

View(repos_data[repos_data$generalProjectCategory == 'No AI-ML' &
                  !is.na(repos_data$coverage) &
                  repos_data$coverage < 50,])


##########################################################################
# Plotting the coverage grouped by project category and size (Boxplot)
##########################################################################

# getting the stats for the commits rate per day grouped by project category and size
coverageByProjectCategoryAndSize <-
  summarise(group_by(repos_data[!is.na(repos_data$coverage),], loc_size, generalProjectCategory), 
            count = length(coverage),
            median = median(coverage),
            mean = mean(coverage))

# boxplots commits rate per day grouped by project category and LOC size
ggplot(repos_data, aes(x=loc_size, y=coverage, fill=generalProjectCategory)) + 
  geom_boxplot() +
  # geom_boxplot(outlier.shape = NA) +
  # coord_cartesian(ylim =  c(0, 3)) +
  geom_text(data = coverageByProjectCategoryAndSize, aes(loc_size, median, label = round(median, digits = 2)), 
            position = position_dodge(width = 0.8), size = 3, vjust = -0.5) + 
  labs(fill="Category") +
  xlab("LOC Size") +
  ylab("Coverage")




repos_month_date_intervals




############################################################################
# Applying the MWW test - Build/Run duration - per project category and size
############################################################################

python_language <- c("Python", "Jupyter Notebook")

repos_data_temp <- repos_data[repos_data$language %in% python_language,]

stat.test <- repos_data_temp %>%
  group_by(loc_size) %>%
  wilcox_test(medianRunDurationInMinutes ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data_temp %>%
    group_by(loc_size) %>%
    summarise(
      cliffs_estimate = cliff.delta(medianRunDurationInMinutes ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianRunDurationInMinutes ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

metric_summary <-
  summarise(group_by(repos_data_temp, loc_size, generalProjectCategory), 
            projects = length(medianRunDurationInMinutes),
            min = min(medianRunDurationInMinutes, na.rm = TRUE),
            q1 = quantile(medianRunDurationInMinutes, probs = 0.25, na.rm = TRUE),
            median = median(medianRunDurationInMinutes, na.rm = TRUE),
            mean = mean(medianRunDurationInMinutes, na.rm = TRUE),
            q3 = quantile(medianRunDurationInMinutes, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(medianRunDurationInMinutes)$stats[5],
            max = max(medianRunDurationInMinutes, na.rm = TRUE))

# ----------------------------------------
# Visualization: box plots with p-values
# ----------------------------------------

bxp <- ggboxplot(repos_data_temp %>% filter(!is.na(medianRunDurationInMinutes)), x = "loc_size", y = "medianRunDurationInMinutes", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Median Build Duration (Minutes)") +
  scale_y_continuous(
    # expand = c(0, 0),
    # breaks = seq(0, 1, by = 0.25),
    limits = c(0, 180)
  ) +
  stat_pvalue_manual(stat.test, hide.ns = FALSE, label = 'p = {p}\nCliffs\' d = {cliffs_magnitude}',
                     bracket.nudge.y = 0.03) +
  geom_text(data = metric_summary, 
            aes(x=loc_size, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) 

ggpar(bxp,legend = "right", legend.title = "Category")



############################################################################
# Applying the MWW test - Build/Run duration - per project category
############################################################################

python_language <- c("Python", "Jupyter Notebook")

repos_data_temp <- repos_data[repos_data$language %in% python_language,]

stat.test <- repos_data_temp %>%
  wilcox_test(medianRunDurationInMinutes ~ generalProjectCategory)

stat.test <- stat.test %>% mutate(
  repos_data_temp %>%
    summarise(
      cliffs_estimate = cliff.delta(medianRunDurationInMinutes ~ generalProjectCategory)$estimate,
      cliffs_magnitude = cliff.delta(medianRunDurationInMinutes ~ generalProjectCategory)$magnitude),
)

stat.test <- stat.test %>% add_xy_position(x = 'loc_size')

metric_summary <-
  summarise(group_by(repos_data_temp, generalProjectCategory), 
            projects = length(medianRunDurationInMinutes),
            min = min(medianRunDurationInMinutes, na.rm = TRUE),
            q1 = quantile(medianRunDurationInMinutes, probs = 0.25, na.rm = TRUE),
            median = median(medianRunDurationInMinutes, na.rm = TRUE),
            mean = mean(medianRunDurationInMinutes, na.rm = TRUE),
            q3 = quantile(medianRunDurationInMinutes, probs = 0.75, na.rm = TRUE),
            boxplot_max_without_outlier = boxplot.stats(medianRunDurationInMinutes)$stats[5],
            max = max(medianRunDurationInMinutes, na.rm = TRUE))

# ----------------------------------------
# Visualization: box plots with p-values
# ----------------------------------------

# Filtering out NA values
filtered_data <- repos_data_temp[!is.na(repos_data_temp$medianRunDurationInMinutes),]

bxp <- ggboxplot(filtered_data, 
                 x = "generalProjectCategory", 
                 y = "medianRunDurationInMinutes", 
                 fill = "generalProjectCategory",
                 xlab = "LOC Size",
                 ylab = "Median Build Duration (Minutes)") +
  scale_y_continuous(
    # expand = c(0, 0),
    # breaks = seq(0, 1, by = 0.25),
    limits = c(0, 180)
  ) +
  stat_pvalue_manual(stat.test, hide.ns = FALSE, 
                     label = 'p = {p}\nCliffs\' d = {cliffs_magnitude}',
                     bracket.nudge.y = 0.03) +
  geom_text(data = metric_summary, 
            aes(x=generalProjectCategory, y=median, fill=generalProjectCategory, label = round(median, digits = 2)),
            position = position_dodge(width = 0.8), size = 3.5, vjust = -0.5) 

ggpar(bxp, legend = "right", legend.title = "Category")

