##############################################
########### IMPORTING PACKAGES  ##############
##############################################

library(dtw)
library(dtwclust)
library(tidyr)
library(gridExtra)
library(sqldf)

# Fill NA values using linear interpolation
library(zoo)

###########################################################
# Define working directory
###########################################################

current_file_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(current_file_dir)

# set the datasets folder as the working directory
setwd('../datasets')

##################################################
############### LOADING DATASETS #################
##################################################

repos_month_date_intervals <- read.csv2("repos_month_date_intervals.csv", sep = ",", dec=".", na.strings = c('NULL'))

# Define the order of the boxes
loc_size_box_order <- c("small", "medium", "large")
box_order <- c("ML", "No ML")

# Reorder the factor levels
repos_month_date_intervals$loc_size <- reorder(repos_month_date_intervals$loc_size, as.numeric(factor(repos_month_date_intervals$loc_size, levels = loc_size_box_order)))
repos_month_date_intervals$generalProjectCategory <- reorder(repos_month_date_intervals$generalProjectCategory, as.numeric(factor(repos_month_date_intervals$generalProjectCategory, levels = box_order)))

##################################################
# FILTERING PROJECTS WITH SUITABLE COVERAGE DATA #
##################################################

projects_coverage_count <- summarise(
  group_by(repos_month_date_intervals[!is.na(repos_month_date_intervals$lastCoverageInInterval),], proj), 
  coverage_history_count = length(proj))


projects_min_6_monthly_coverage_data <- projects_coverage_count[projects_coverage_count$coverage_history_count >= 6,]$proj

##################################################
### CREATION OF COVERAGE TIME SERIES DATAFRAME ###
##################################################

# ------------------------------------------------
# ML
# ------------------------------------------------
time_series_df.medium_proj.ml <- repos_month_date_intervals %>% filter(proj %in% projects_min_6_monthly_coverage_data &
                                                                         !is.na(lastCoverageInInterval) & 
                                                                         generalProjectCategory == 'ML' &
                                                                         loc_size == 'medium'
) %>% select(proj,
             loc_size,
             intervalOrder,
             lastCoverageInInterval)


# creates a list of lastCoverageInInterval values for each project
time_series.list.medium_proj.ml <- lapply(split(time_series_df.medium_proj.ml$lastCoverageInInterval, time_series_df.medium_proj.ml$proj), as.numeric)

##################################################
# Data Preprocessing (Interpolating and Scaling) #
##################################################

# Linear Interpolation to set the same amount of elements to the time series of all projects
max_length.medium_proj.ml <- max(lengths(time_series.list.medium_proj.ml))
time_series.interpolated.medium_proj.ml <- reinterpolate(time_series.list.medium_proj.ml, new.length = max_length)
time_series.matrix.interpolated.medium_proj.ml <- t(sapply(time_series.interpolated.medium_proj.ml, unlist))

# ------------------------------------------------
# No ML
# ------------------------------------------------
time_series_df.medium_proj.no_ml <- repos_month_date_intervals %>% filter(proj %in% projects_min_6_monthly_coverage_data &
                                                                            !is.na(lastCoverageInInterval) & 
                                                                            generalProjectCategory == 'No ML' &
                                                                            loc_size == 'medium'
) %>% select(proj,
             loc_size,
             intervalOrder,
             lastCoverageInInterval)


# creates a list of lastCoverageInInterval values for each project
time_series.list.medium_proj.no_ml <- lapply(split(time_series_df.medium_proj.no_ml$lastCoverageInInterval, time_series_df.medium_proj.no_ml$proj), as.numeric)

##################################################
# Data Preprocessing (Interpolating and Scaling) #
##################################################

# Linear Interpolation to set the same amount of elements to the time series of all projects
max_length.medium_proj.no_ml <- max(lengths(time_series.list.medium_proj.no_ml))
time_series.interpolated.medium_proj.no_ml <- reinterpolate(time_series.list.medium_proj.no_ml, new.length = max_length)
time_series.matrix.interpolated.medium_proj.no_ml <- t(sapply(time_series.interpolated.medium_proj.no_ml, unlist))

########################################
# ploting time series
########################################

# ------------------------------------------------
# ML
# ------------------------------------------------

long_df.ml <- enframe(time_series.interpolated.medium_proj.ml, name = "proj", value = "medianRunDurationInMinutes") %>%
  unnest(medianRunDurationInMinutes)

# Create a new column with the sequence that restarts when "Variable" changes
long_df.ml <- long_df.ml %>%
  group_by(proj) %>%
  mutate(Sequence = row_number())

# Plot the data as time series with the added Sequence column
ml_medium_coverage_plot <- ggplot() +
  geom_line(data = long_df.ml, aes(x = Sequence, y = medianRunDurationInMinutes, group = proj, color = proj)) +
  labs(x = "time", y = "Test Coverage") +
  theme_minimal() +
  theme(legend.position = "none",
        axis.title.x = element_blank(), 
        axis.text.x = element_blank(),
        plot.title = element_text(hjust = 0.5,
                                  face="bold"),
        plot.subtitle=element_text(hjust=0.5)) +
  labs(title="Medium-sized ML projects") +
  scale_y_continuous(limits = c(0, 100))

# ------------------------------------------------
# No ML
# ------------------------------------------------

long_df.no_ml <- enframe(time_series.interpolated.medium_proj.no_ml, name = "proj", value = "medianRunDurationInMinutes") %>%
  unnest(medianRunDurationInMinutes)

# Create a new column with the sequence that restarts when "Variable" changes
long_df.no_ml <- long_df.no_ml %>%
  group_by(proj) %>%
  mutate(Sequence = row_number())

# Plot the data as time series with the added Sequence column
no_ml_medium_coverage_plot <- ggplot() +
  geom_line(data = long_df.no_ml, aes(x = Sequence, y = medianRunDurationInMinutes, group = proj, color = proj)) +
  labs(x = "time", y = "Test Coverage") +
  theme_minimal() +
  theme(legend.position = "none",
        axis.title.x = element_blank(), 
        axis.text.x = element_blank(),
        plot.title = element_text(hjust = 0.5,
                                  face="bold"),
        plot.subtitle=element_text(hjust=0.5)) +
  labs(title="Medium-sized non-ML projects") +
  scale_y_continuous(limits = c(0, 100))

plots <- list()
plots[[1]] <- ml_medium_coverage_plot
plots[[2]] <- no_ml_medium_coverage_plot

arranged_plots <- grid.arrange(
  grobs = plots,
  ncol = 2
)
