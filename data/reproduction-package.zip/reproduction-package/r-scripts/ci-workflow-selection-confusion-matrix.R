##############################################
########### IMPORTING PACKAGES  ##############
##############################################

library(dplyr)
library(jsonlite) 
library(ggplot2)
library(reshape2)
library(openxlsx)

###########################################################
# Define working directory
###########################################################

current_file_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(current_file_dir)

# set the datasets folder as the working directory
setwd('../datasets')

###########################################################
# Importing workflow sample to generat xlsx to manual check
###########################################################

# Parse the cleaned JSON
workflow_sample_json <- jsonlite::fromJSON("workflow-sample-check-ci-classifier-method.json")

# Convert  the JSON data to dataframe 
workflow_sample_data <- as.data.frame(workflow_sample_json) 

###########################################################
# Export workflow sample from json to excel for manual check
###########################################################

# library(openxlsx)
# wb <- createWorkbook()
# 
# # Add the data frames to different sheets in the workbook
# addWorksheet(wb, "workflows")
# writeData(wb, sheet = 1, x = workflow_sample_data, startCol = 1, startRow = 1)
# 
# # Save the workbook to an Excel file
# saveWorkbook(wb, "workflow-sample-check-ci-classifier-method.xlsx", overwrite = TRUE)

###########################################################
# Read xlsx with manual CI workflow classification
###########################################################

# Read Excel file
workflow_sample_ci_manual_check <- read.xlsx("workflow-sample-check-ci-classifier-method-manual-check-result.xlsx", sheet = "workflows")

manual_check_result <- as.numeric(workflow_sample_ci_manual_check$manual_check)
predicted <- as.numeric(workflow_sample_ci_manual_check$classifier_result)

# Confusion matrix
conf_matrix <- table(predicted, manual_check_result)
conf_matrix

# Calculate accuracy, sensitivity, and specificity
TN <- conf_matrix[1,1]
FP <- conf_matrix[2,1]
FN <- conf_matrix[1,2]
TP <- conf_matrix[2,2]

# define the confusion matrix
confusion_matrix <- matrix(c(TN, FN, 
                             FP, TP), 
                           nrow = 2, 
                           dimnames = list(c("Actual Negative", "Actual Positive"), 
                                           c("Predicted Negative", "Predicted Positive")))

# calculate accuracy, sensitivity, and specificity
accuracy <- sum(diag(confusion_matrix)) / sum(confusion_matrix)
sensitivity <- confusion_matrix[2, 2] / sum(confusion_matrix[2, ])
specificity <- confusion_matrix[1, 1] / sum(confusion_matrix[1, ])

# Calculate precision and recall
precision <- TP / (TP + FP)
recall <- sensitivity  # Recall is the same as sensitivity in binary classification

# Print the results
cat("Confusion Matrix:\n", confusion_matrix, "\n\n")
cat("Accuracy:", accuracy, "\n")
cat("Sensitivity (Recall):", sensitivity, "\n")
cat("Specificity:", specificity, "\n")
cat("Precision:", precision, "\n")
cat("Recall:", recall, "\n")

# plot the confusion matrix
ggplot(data = melt(confusion_matrix), aes(x = Var2, y = Var1, fill = value)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "steelblue") +
  theme_bw() +
  labs(title = "Confusion Matrix",
       subtitle = paste0("Accuracy: ", round(accuracy, 2), " | Precision: ", round(precision, 2), " | Recall: ", round(recall, 2)),
       x = "Predicted Class",
       y = "Actual Class",
       fill = "Count")
